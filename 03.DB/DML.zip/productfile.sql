--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PRODUCTFILE
--------------------------------------------------------

  CREATE TABLE "TEAM"."PRODUCTFILE" 
   (	"FILESEQ" NUMBER, 
	"PRODUCTSEQ" NUMBER, 
	"FILENAME" VARCHAR2(100 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.PRODUCTFILE
SET DEFINE OFF;
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (1,1,'금융 프로젝트 요구사항 명세서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (2,2,'금융 프로젝트 기술 명세서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (3,3,'금융 프로젝트 화면 설계서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (4,4,'금융 프로젝트 데이터베이스 설계서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (5,5,'금융 프로젝트 소스코드');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (6,6,'금융 프로젝트 위험 관리 계획서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (7,7,'금융 프로젝트 변경 제어 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (8,8,'금융 프로젝트 보고서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (9,9,'금융 프로젝트 배포 및 운영 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (10,10,'금융 프로젝트 유지 보수 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (11,11,'크롤링 프로그램 요구사항 명세서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (12,12,'크롤링 프로그램 기술 명세서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (13,13,'크롤링 프로젝트 화면 설계서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (14,14,'크롤링 프로젝트 데이터베이스 설계서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (15,15,'크롤링 프로젝트 소스코드');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (16,16,'크롤링 프로젝트 위험 관리 계획서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (17,17,'크롤링 프로젝트 변경 제어 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (18,18,'크롤링 프로젝트 보고서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (19,19,'크롤링 프로젝트 배포 및 운영 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (20,20,'크롤링 프로젝트 유지 보수 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (21,21,'POS프로젝트 요구사항 명세서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (22,22,'POS프로젝트 기술 명세서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (23,23,'POS프로젝트 화면 설계서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (24,24,'POS프로젝트 데이터베이스 설계서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (25,25,'POS프로젝트 소스코드');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (26,26,'POS프로젝트 위험 관리 계획서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (27,27,'POS프로젝트 변경 제어 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (28,28,'POS프로젝트 보고서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (29,29,'POS프로젝트 배포 및 운영 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (30,30,'POS프로젝트 유지 보수 문서');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (49,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (50,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (51,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (52,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (53,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (54,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (55,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (56,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (57,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (58,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (59,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (60,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (61,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (62,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (63,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (64,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (65,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (66,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (93,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (94,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (95,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (84,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (85,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (87,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (92,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (96,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (97,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (99,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (101,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (102,null,'결재 안건 요청서1.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (103,null,'결재 안건 요청서2.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (104,null,'결재 안건 요청서3.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (105,null,'결재 안건 요청서4.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (106,null,'결재 안건 요청서1.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (107,null,'결재 안건 요청서2.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (108,40,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (110,null,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (112,42,'결재 안건 요청서2.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (113,44,'산출물.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (114,null,'결재 안건 요청서1.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (115,31,'결재 안건 요청서.pdf');
Insert into TEAM.PRODUCTFILE (FILESEQ,PRODUCTSEQ,FILENAME) values (116,32,'결재 안건 요청서.pdf');
--------------------------------------------------------
--  DDL for Index SYS_C009009
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C009009" ON "TEAM"."PRODUCTFILE" ("FILESEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table PRODUCTFILE
--------------------------------------------------------

  ALTER TABLE "TEAM"."PRODUCTFILE" ADD PRIMARY KEY ("FILESEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."PRODUCTFILE" MODIFY ("FILENAME" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PRODUCTFILE" MODIFY ("FILESEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table PRODUCTFILE
--------------------------------------------------------

  ALTER TABLE "TEAM"."PRODUCTFILE" ADD FOREIGN KEY ("PRODUCTSEQ")
	  REFERENCES "TEAM"."PRODUCT" ("PRODUCTSEQ") ENABLE;
