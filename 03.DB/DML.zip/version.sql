--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table VERSION
--------------------------------------------------------

  CREATE TABLE "TEAM"."VERSION" 
   (	"VERSIONSEQ" NUMBER, 
	"VERSION" VARCHAR2(15 BYTE), 
	"CONTENT" VARCHAR2(4000 BYTE), 
	"VERSIONDATE" DATE, 
	"FILENAME" VARCHAR2(100 BYTE), 
	"PROJECTSEQ" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.VERSION
SET DEFINE OFF;
Insert into TEAM.VERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ) values (1,'1.01','금융상품 추천 어플리케이션 제작의 두번째 버전',to_date('22/03/01','RR/MM/DD'),null,1);
Insert into TEAM.VERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ) values (2,'1.02','금융상품 추천 어플리케이션 제작의 세번째 버전',to_date('22/06/01','RR/MM/DD'),null,1);
Insert into TEAM.VERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ) values (3,'1.03','금융상품 추천 어플리케이션 제작의 네번째 버전',to_date('22/09/01','RR/MM/DD'),null,1);
Insert into TEAM.VERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ) values (21,'1.12','금융상품 추천 어플리케이션 제작의 다섯번째 버전',to_date('23/06/10','RR/MM/DD'),'버전 파일2.pdf',1);
Insert into TEAM.VERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ) values (22,'1.16','버전 업데이트입니다.',to_date('23/06/11','RR/MM/DD'),'결재 안건 요청서.pdf',1);
Insert into TEAM.VERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ) values (24,'베타버전','금융상품 추천 어플리케이션의 베타버전은 개인 맞춤형 금융 조언을 제공하는 혁신적인 플랫폼입니다. 이 어플리케이션은 사용자의 금융 목표, 수입 및 지출 패턴, 투자 성향 등을 분석하여 최적의 금융상품을 추천해 줍니다.

베타버전에서는 사용자의 프로필 정보를 수집하고, 그에 기반하여 금융상품 추천 알고리즘을 테스트합니다. 이를 통해 사용자는 자신에게 가장 적합한 예금 상품, 대출 상품, 투자 상품 등을 발견할 수 있습니다.

또한, 베타버전에서는 금융 교육 자료와 투자 팁, 재무 관리 가이드 등의 추가 기능도 제공됩니다. 이를 통해 사용자는 금융적인 지식과 노하우를 습득하며 자신의 재무 상태를 효과적으로 관리할 수 있습니다.

베타버전은 사용자의 피드백과 경험을 수집하여 서비스를 개선하는 데 활용될 것입니다. 최종 버전에서는 더 많은 기능과 개인화된 추천 알고리즘을 제공하여 사용자의 금융적인 목표 달성을 도와줄 것입니다.




',to_date('23/05/31','RR/MM/DD'),'금융상품 추천 어플리케이션 1.pdf',1);
--------------------------------------------------------
--  DDL for Index SYS_C009055
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C009055" ON "TEAM"."VERSION" ("VERSIONSEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table VERSION
--------------------------------------------------------

  ALTER TABLE "TEAM"."VERSION" ADD PRIMARY KEY ("VERSIONSEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."VERSION" MODIFY ("PROJECTSEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."VERSION" MODIFY ("VERSIONDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."VERSION" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."VERSION" MODIFY ("VERSION" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."VERSION" MODIFY ("VERSIONSEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table VERSION
--------------------------------------------------------

  ALTER TABLE "TEAM"."VERSION" ADD FOREIGN KEY ("PROJECTSEQ")
	  REFERENCES "TEAM"."PROJECT" ("PROJECTSEQ") ENABLE;
