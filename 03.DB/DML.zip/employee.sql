--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table EMPLOYEE
--------------------------------------------------------

  CREATE TABLE "TEAM"."EMPLOYEE" 
   (	"EMPLOYEESEQ" NUMBER, 
	"NAME" VARCHAR2(15 BYTE), 
	"TEL" VARCHAR2(50 BYTE), 
	"JOINDATE" DATE, 
	"BIRTH" VARCHAR2(50 BYTE), 
	"POSITION" VARCHAR2(15 BYTE), 
	"LV" NUMBER, 
	"EMAIL" VARCHAR2(50 BYTE), 
	"ADDRESS" VARCHAR2(200 BYTE), 
	"TEAMSEQ" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.EMPLOYEE
SET DEFINE OFF;
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (1,'오현소','010-9314-4300',to_date('10/03/20','RR/MM/DD'),'840604-2475651','사원',1,'jane341@gmail.com','부산광역시 서울특별시 강서구 공항대로 4동, 우편번호 03333',1);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (2,'최재현','010-7446-5208',to_date('10/06/01','RR/MM/DD'),'831206-1774844','부장',2,'emma821@gmail.com','부산광역시 서울특별시 마포구 홍익로 2동, 우편번호 05555',1);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (3,'한지현','010-2097-6062',to_date('10/07/27','RR/MM/DD'),'860830-1192375','사원',1,'michael371@hotmail.com','경기도 서울특별시 송파구 올림픽로 5동, 우편번호 01111',1);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (4,'권민린','010-9310-8514',to_date('10/07/29','RR/MM/DD'),'830220-1838136','사원',1,'alex67@gmail.com','부산광역시 서울특별시 강남구 언주로 4동, 우편번호 01111',1);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (5,'강성제','010-2348-9076',to_date('10/09/09','RR/MM/DD'),'850616-1618553','사원',1,'jane750@gmail.com','서울특별시 서울특별시 마포구 홍익로 4동, 우편번호 01111',1);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (6,'전연현','010-7584-6173',to_date('10/09/11','RR/MM/DD'),'860524-2974471','부장',2,'sophia9@yahoo.com','대구광역시 서울특별시 마포구 홍익로 5동, 우편번호 03333',2);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (7,'서재수','010-4999-7611',to_date('10/09/25','RR/MM/DD'),'851116-2827693','사원',1,'jane527@gmail.com','인천광역시 서울특별시 종로구 인사동길 1동, 우편번호 04444',2);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (8,'최호재','010-9357-7100',to_date('10/10/28','RR/MM/DD'),'860809-2132386','사원',1,'emma685@yahoo.com','서울특별시 서울특별시 강서구 공항대로 1동, 우편번호 02222',2);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (9,'서정엽','010-3322-9113',to_date('11/01/02','RR/MM/DD'),'840903-1133227','사원',1,'emma358@example.com','인천광역시 서울특별시 송파구 올림픽로 4동, 우편번호 02222',2);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (10,'임현우','010-2953-2801',to_date('11/02/11','RR/MM/DD'),'850727-1958292','사원',1,'alex747@test.com','부산광역시 서울특별시 강남구 언주로 5동, 우편번호 04444',2);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (11,'송소수','010-8679-4138',to_date('11/06/25','RR/MM/DD'),'860529-2724262','부장',2,'emma155@example.com','부산광역시 서울특별시 송파구 올림픽로 4동, 우편번호 05555',3);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (12,'안훈현','010-9926-7807',to_date('11/07/16','RR/MM/DD'),'860231-2996990','사원',1,'jane697@yahoo.com','서울특별시 서울특별시 종로구 인사동길 3동, 우편번호 03333',3);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (13,'윤훈재','010-3362-7619',to_date('12/02/09','RR/MM/DD'),'861115-2321800','사원',1,'alex416@hotmail.com','인천광역시 서울특별시 강남구 언주로 3동, 우편번호 04444',3);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (14,'이제민','010-1783-2174',to_date('12/04/07','RR/MM/DD'),'851231-1528027','사원',1,'alex355@test.com','부산광역시 서울특별시 종로구 인사동길 1동, 우편번호 01111',3);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (15,'송현진','010-9022-8390',to_date('12/08/31','RR/MM/DD'),'860404-1652784','사원',1,'emma83@gmail.com','경기도 서울특별시 마포구 홍익로 4동, 우편번호 03333',3);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (16,'임재지','010-3181-7158',to_date('13/03/07','RR/MM/DD'),'860608-1434681','부장',2,'john895@test.com','부산광역시 서울특별시 종로구 인사동길 5동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (17,'류우호','010-1888-6333',to_date('13/03/18','RR/MM/DD'),'881026-2154383','사원',1,'john593@yahoo.com','경기도 서울특별시 송파구 올림픽로 4동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (18,'전성연','010-2423-3308',to_date('13/04/22','RR/MM/DD'),'880106-2770383','사원',1,'john544@yahoo.com','서울특별시 서울특별시 송파구 올림픽로 3동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (19,'한민동','010-6620-2847',to_date('13/05/16','RR/MM/DD'),'880126-1317486','사원',1,'sophia261@hotmail.com','대구광역시 서울특별시 강서구 공항대로 2동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (20,'황동정','010-4413-7409',to_date('13/06/21','RR/MM/DD'),'860201-1757096','사원',1,'alex952@yahoo.com','부산광역시 서울특별시 강서구 공항대로 1동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (21,'장태수','010-7682-4110',to_date('13/06/26','RR/MM/DD'),'890711-1584392','부장',2,'alex76@yahoo.com','부산광역시 서울특별시 강남구 언주로 1동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (22,'박완제','010-2987-4718',to_date('13/07/01','RR/MM/DD'),'880208-1048541','사원',1,'michael825@test.com','인천광역시 서울특별시 강남구 언주로 3동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (23,'오욱섭','010-2608-3878',to_date('13/07/11','RR/MM/DD'),'891012-1247169','사원',1,'jane561@test.com','경기도 서울특별시 마포구 홍익로 2동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (24,'이지완','010-9969-2579',to_date('13/09/29','RR/MM/DD'),'860520-2295313','사원',1,'emma507@test.com','인천광역시 서울특별시 강남구 언주로 1동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (25,'황완연','010-5683-1856',to_date('13/10/06','RR/MM/DD'),'861110-2571670','사원',1,'sophia380@test.com','대구광역시 서울특별시 강서구 공항대로 1동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (26,'임지소','010-4511-4016',to_date('13/11/08','RR/MM/DD'),'890907-2882143','부장',2,'michael833@test.com','서울특별시 서울특별시 강남구 언주로 1동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (27,'오섭린','010-4360-9178',to_date('13/11/16','RR/MM/DD'),'890629-1817718','사원',1,'alex671@test.com','대구광역시 서울특별시 강남구 언주로 3동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (28,'전연림','010-3667-2948',to_date('13/11/17','RR/MM/DD'),'890420-2751869','사원',1,'emma269@test.com','부산광역시 서울특별시 강남구 언주로 3동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (29,'이훈소','010-8915-7838',to_date('14/01/18','RR/MM/DD'),'891030-1910705','사원',1,'michael596@gmail.com','부산광역시 서울특별시 강서구 공항대로 2동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (30,'안호진','010-9506-8873',to_date('14/02/09','RR/MM/DD'),'871221-1823558','사원',1,'emma542@hotmail.com','인천광역시 서울특별시 강남구 언주로 2동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (31,'임재제','010-7017-9242',to_date('14/05/20','RR/MM/DD'),'901118-2758216','부장',2,'jane650@hotmail.com','경기도 서울특별시 강서구 공항대로 5동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (32,'오소현','010-2376-3094',to_date('14/07/15','RR/MM/DD'),'881222-2500493','사원',1,'alex50@example.com','서울특별시 서울특별시 송파구 올림픽로 3동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (33,'박소진','010-7529-4660',to_date('14/07/17','RR/MM/DD'),'890209-1557856','사원',1,'alex948@yahoo.com','경기도 서울특별시 강남구 언주로 2동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (34,'전엽현','010-1053-4277',to_date('14/07/29','RR/MM/DD'),'880827-2634777','사원',1,'emma31@test.com','경기도 서울특별시 강남구 언주로 4동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (35,'윤태동','010-6804-9464',to_date('14/08/20','RR/MM/DD'),'890804-1678078','사원',1,'sophia961@example.com','인천광역시 서울특별시 종로구 인사동길 4동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (36,'최채현','010-5264-6132',to_date('14/11/09','RR/MM/DD'),'890514-1798224','부장',2,'alex27@hotmail.com','대구광역시 서울특별시 종로구 인사동길 5동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (37,'류소현','010-4632-1770',to_date('14/11/17','RR/MM/DD'),'870411-1785915','사원',1,'michael110@hotmail.com','부산광역시 서울특별시 마포구 홍익로 1동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (38,'안동엽','010-6670-4900',to_date('15/01/19','RR/MM/DD'),'910614-1435414','사원',1,'jane747@gmail.com','서울특별시 서울특별시 송파구 올림픽로 5동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (39,'김진정','010-8171-1512',to_date('15/01/24','RR/MM/DD'),'910127-1517461','사원',1,'sophia853@hotmail.com','경기도 서울특별시 송파구 올림픽로 3동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (40,'황제채','010-1330-8931',to_date('15/05/01','RR/MM/DD'),'880317-1029393','사원',1,'jane953@example.com','부산광역시 서울특별시 종로구 인사동길 4동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (41,'서현정','010-6876-6510',to_date('15/05/11','RR/MM/DD'),'910808-1319113','부장',2,'john571@example.com','인천광역시 서울특별시 송파구 올림픽로 5동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (42,'강성호','010-6095-1652',to_date('15/08/29','RR/MM/DD'),'880114-1701355','사원',1,'michael62@yahoo.com','부산광역시 서울특별시 마포구 홍익로 3동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (43,'강현린','010-5423-2972',to_date('15/09/15','RR/MM/DD'),'891219-1146553','사원',1,'jane920@example.com','대구광역시 서울특별시 종로구 인사동길 1동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (44,'서호린','010-3966-3820',to_date('15/10/27','RR/MM/DD'),'910222-2481905','사원',1,'michael616@example.com','서울특별시 서울특별시 강남구 언주로 3동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (45,'정수현','010-4316-1638',to_date('15/12/27','RR/MM/DD'),'911222-2701718','사원',1,'john587@test.com','경기도 서울특별시 송파구 올림픽로 4동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (46,'이림호','010-6949-1727',to_date('16/03/02','RR/MM/DD'),'910226-2464298','부장',2,'jane380@hotmail.com','인천광역시 서울특별시 강남구 언주로 4동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (47,'한동린','010-1072-1390',to_date('16/06/14','RR/MM/DD'),'890105-2645036','사원',1,'alex395@example.com','부산광역시 서울특별시 강남구 언주로 5동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (48,'송엽제','010-3902-3262',to_date('16/06/20','RR/MM/DD'),'900115-2402039','사원',1,'alex416@test.com','부산광역시 서울특별시 강서구 공항대로 5동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (49,'윤민성','010-6180-9410',to_date('16/07/05','RR/MM/DD'),'900116-2426504','사원',1,'alex796@gmail.com','인천광역시 서울특별시 강서구 공항대로 3동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (50,'권호정','010-2201-4201',to_date('16/09/12','RR/MM/DD'),'890711-1955043','사원',1,'jane143@hotmail.com','인천광역시 서울특별시 강서구 공항대로 1동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (51,'황태수','010-4404-1191',to_date('16/10/18','RR/MM/DD'),'890524-2132650','부장',2,'alex376@hotmail.com','부산광역시 서울특별시 강남구 언주로 2동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (52,'임재성','010-4307-3159',to_date('16/11/10','RR/MM/DD'),'890829-1306584','사원',1,'john732@yahoo.com','경기도 서울특별시 강서구 공항대로 2동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (53,'류지정','010-1704-7100',to_date('16/12/02','RR/MM/DD'),'900925-1308427','사원',1,'john495@gmail.com','인천광역시 서울특별시 마포구 홍익로 1동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (54,'한현동','010-2689-1020',to_date('16/12/15','RR/MM/DD'),'910708-1742797','사원',1,'jane676@example.com','인천광역시 서울특별시 종로구 인사동길 3동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (55,'송훈성','010-6409-6101',to_date('17/05/16','RR/MM/DD'),'911215-2673221','사원',1,'john622@gmail.com','대구광역시 서울특별시 강남구 언주로 2동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (56,'강현림','010-6586-7945',to_date('17/05/28','RR/MM/DD'),'910230-2640895','사원',1,'michael503@test.com','경기도 서울특별시 강서구 공항대로 5동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (57,'송지연','010-6239-8694',to_date('17/10/04','RR/MM/DD'),'910119-2822695','사원',1,'sophia831@test.com','부산광역시 서울특별시 강남구 언주로 3동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (58,'김우재','010-4441-8226',to_date('17/10/14','RR/MM/DD'),'901219-2875570','사원',1,'michael103@gmail.com','경기도 서울특별시 강남구 언주로 1동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (59,'최림진','010-4576-4543',to_date('17/10/21','RR/MM/DD'),'910629-1226981','사원',1,'emma854@gmail.com','서울특별시 서울특별시 강서구 공항대로 3동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (60,'강동완','010-1426-9879',to_date('17/10/23','RR/MM/DD'),'900523-1756345','사원',1,'sophia423@yahoo.com','대구광역시 서울특별시 강남구 언주로 3동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (61,'권태엽','010-1465-5273',to_date('17/11/27','RR/MM/DD'),'900702-2973917','사원',1,'jane739@hotmail.com','부산광역시 서울특별시 마포구 홍익로 2동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (62,'송동지','010-1392-1085',to_date('17/12/18','RR/MM/DD'),'910427-2029347','사원',1,'alex390@test.com','대구광역시 서울특별시 강남구 언주로 1동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (63,'권엽림','010-2451-1886',to_date('17/12/26','RR/MM/DD'),'910916-1914177','사원',1,'michael645@test.com','서울특별시 서울특별시 종로구 인사동길 2동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (64,'서채엽','010-8746-5070',to_date('18/03/02','RR/MM/DD'),'920404-2022239','사원',1,'emma103@example.com','인천광역시 서울특별시 종로구 인사동길 1동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (65,'장섭정','010-9414-8396',to_date('18/04/28','RR/MM/DD'),'931201-1404279','사원',1,'emma409@hotmail.com','경기도 서울특별시 강서구 공항대로 5동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (66,'오엽호','010-5759-3087',to_date('18/06/03','RR/MM/DD'),'930616-1143991','사원',1,'michael973@test.com','서울특별시 서울특별시 종로구 인사동길 3동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (67,'조소연','010-7845-4728',to_date('18/06/16','RR/MM/DD'),'910610-1946221','사원',1,'emma961@hotmail.com','서울특별시 서울특별시 강남구 언주로 3동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (68,'서린림','010-9505-8828',to_date('18/09/15','RR/MM/DD'),'941116-1280083','사원',1,'michael702@hotmail.com','서울특별시 서울특별시 종로구 인사동길 5동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (69,'권제욱','010-9254-6000',to_date('18/09/28','RR/MM/DD'),'920810-1994863','사원',1,'sophia343@hotmail.com','대구광역시 서울특별시 마포구 홍익로 4동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (70,'윤림완','010-5844-2121',to_date('18/10/31','RR/MM/DD'),'930431-2924667','사원',1,'emma505@yahoo.com','경기도 서울특별시 강서구 공항대로 4동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (71,'황수우','010-6430-2751',to_date('18/12/29','RR/MM/DD'),'910119-2040492','사원',1,'emma246@test.com','경기도 서울특별시 강서구 공항대로 1동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (72,'송수림','010-7863-4257',to_date('19/03/03','RR/MM/DD'),'951112-1074619','사원',1,'michael695@hotmail.com','경기도 서울특별시 마포구 홍익로 4동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (73,'조수훈','010-5845-6815',to_date('19/04/13','RR/MM/DD'),'941025-2587254','사원',1,'sophia698@hotmail.com','서울특별시 서울특별시 마포구 홍익로 5동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (74,'김섭림','010-5831-2068',to_date('19/05/04','RR/MM/DD'),'950503-2738168','사원',1,'emma830@example.com','부산광역시 서울특별시 송파구 올림픽로 2동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (75,'박민완','010-6248-4769',to_date('19/06/07','RR/MM/DD'),'920602-2143714','사원',1,'alex626@yahoo.com','서울특별시 서울특별시 송파구 올림픽로 1동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (76,'황섭정','010-2836-4703',to_date('19/11/10','RR/MM/DD'),'920627-1120440','사원',1,'jane751@example.com','경기도 서울특별시 강남구 언주로 1동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (77,'권진완','010-6116-4342',to_date('20/01/19','RR/MM/DD'),'960701-1941792','사원',1,'jane557@yahoo.com','서울특별시 서울특별시 강남구 언주로 1동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (78,'서수진','010-6154-8470',to_date('20/02/21','RR/MM/DD'),'940910-1472679','사원',1,'jane521@yahoo.com','부산광역시 서울특별시 마포구 홍익로 1동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (79,'정욱수','010-2086-7716',to_date('20/03/11','RR/MM/DD'),'931003-1574317','사원',1,'john304@hotmail.com','경기도 서울특별시 마포구 홍익로 2동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (80,'서태현','010-3734-6808',to_date('20/06/04','RR/MM/DD'),'960709-1038286','사원',1,'sophia73@test.com','부산광역시 서울특별시 송파구 올림픽로 1동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (81,'장연민','010-5124-3181',to_date('20/06/21','RR/MM/DD'),'961122-1187843','사원',1,'emma106@gmail.com','서울특별시 서울특별시 강남구 언주로 4동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (82,'황훈태','010-1505-4080',to_date('20/07/31','RR/MM/DD'),'931015-2575081','사원',1,'jane129@example.com','인천광역시 서울특별시 종로구 인사동길 1동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (83,'김재민','010-1244-2103',to_date('20/10/07','RR/MM/DD'),'931031-1475364','사원',1,'sophia598@yahoo.com','경기도 서울특별시 강서구 공항대로 4동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (84,'윤린동','010-1380-3508',to_date('20/10/13','RR/MM/DD'),'930604-1445798','사원',1,'sophia23@yahoo.com','대구광역시 서울특별시 강남구 언주로 3동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (85,'오민재','010-4420-5644',to_date('20/11/21','RR/MM/DD'),'960414-2845632','사원',1,'john357@test.com','부산광역시 서울특별시 강서구 공항대로 5동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (86,'전현소','010-9696-2441',to_date('20/12/17','RR/MM/DD'),'960307-2404155','사원',1,'sophia686@example.com','경기도 서울특별시 강서구 공항대로 2동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (87,'전현진','010-9254-8298',to_date('21/01/17','RR/MM/DD'),'970425-2668879','사원',1,'jane268@example.com','부산광역시 서울특별시 강남구 언주로 2동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (88,'박수섭','010-9986-5675',to_date('21/05/11','RR/MM/DD'),'950211-1242830','사원',1,'emma451@yahoo.com','대구광역시 서울특별시 송파구 올림픽로 5동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (89,'장재지','010-8377-3191',to_date('21/06/21','RR/MM/DD'),'940313-1747548','사원',1,'emma19@yahoo.com','서울특별시 서울특별시 종로구 인사동길 1동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (90,'조현제','010-1238-7746',to_date('21/07/18','RR/MM/DD'),'960415-2428815','사원',1,'emma987@test.com','부산광역시 서울특별시 종로구 인사동길 3동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (91,'박욱림','010-1506-6054',to_date('21/08/03','RR/MM/DD'),'971231-1077305','사원',1,'john822@example.com','인천광역시 서울특별시 종로구 인사동길 4동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (92,'서태엽','010-9940-5535',to_date('21/08/16','RR/MM/DD'),'970415-1401336','사원',1,'sophia770@hotmail.com','부산광역시 서울특별시 송파구 올림픽로 3동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (93,'강채지','010-7865-7332',to_date('21/08/29','RR/MM/DD'),'940904-2058569','사원',1,'jane522@test.com','경기도 서울특별시 강서구 공항대로 5동, 우편번호 04444',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (94,'권현섭','010-7640-3148',to_date('21/11/07','RR/MM/DD'),'940813-1161895','사원',1,'michael780@yahoo.com','대구광역시 서울특별시 송파구 올림픽로 1동, 우편번호 01111',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (95,'김엽완','010-6372-4016',to_date('21/12/18','RR/MM/DD'),'940604-1970655','사원',1,'alex408@test.com','서울특별시 서울특별시 마포구 홍익로 5동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (96,'정섭엽','010-4767-8871',to_date('22/01/02','RR/MM/DD'),'960808-1550616','사원',1,'emma624@gmail.com','부산광역시 서울특별시 송파구 올림픽로 5동, 우편번호 05555',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (97,'김훈현','010-6418-4518',to_date('22/02/21','RR/MM/DD'),'950606-1816103','사원',1,'michael828@yahoo.com','인천광역시 서울특별시 강남구 언주로 5동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (98,'오민소','010-3784-6653',to_date('22/06/24','RR/MM/DD'),'960606-1317454','사원',1,'emma168@example.com','인천광역시 서울특별시 강남구 언주로 3동, 우편번호 02222',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (99,'한연림','010-7516-2890',to_date('22/11/06','RR/MM/DD'),'950714-2511269','사원',1,'alex583@yahoo.com','인천광역시 서울특별시 종로구 인사동길 3동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (100,'권성린','010-3757-7820',to_date('22/12/24','RR/MM/DD'),'960729-1193234','사원',1,'emma809@gmail.com','대구광역시 서울특별시 종로구 인사동길 4동, 우편번호 03333',null);
Insert into TEAM.EMPLOYEE (EMPLOYEESEQ,NAME,TEL,JOINDATE,BIRTH,POSITION,LV,EMAIL,ADDRESS,TEAMSEQ) values (109,'연진섭','010-1122-3344',to_date('23/06/13','RR/MM/DD'),'2023-06-12','사원',1,'frotage1@gmail.com','Pestalozzistr',null);
--------------------------------------------------------
--  DDL for Index SYS_C008900
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C008900" ON "TEAM"."EMPLOYEE" ("EMPLOYEESEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table EMPLOYEE
--------------------------------------------------------

  ALTER TABLE "TEAM"."EMPLOYEE" ADD PRIMARY KEY ("EMPLOYEESEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("ADDRESS" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("EMAIL" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("LV" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("POSITION" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("BIRTH" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("JOINDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("TEL" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."EMPLOYEE" MODIFY ("EMPLOYEESEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table EMPLOYEE
--------------------------------------------------------

  ALTER TABLE "TEAM"."EMPLOYEE" ADD FOREIGN KEY ("TEAMSEQ")
	  REFERENCES "TEAM"."TEAM" ("TEAMSEQ") ENABLE;
