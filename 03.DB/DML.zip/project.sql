--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PROJECT
--------------------------------------------------------

  CREATE TABLE "TEAM"."PROJECT" 
   (	"PROJECTSEQ" NUMBER, 
	"NAME" VARCHAR2(100 BYTE), 
	"STARTDATE" DATE, 
	"ENDDATE" DATE, 
	"PROJECTTYPE" VARCHAR2(15 BYTE), 
	"RNDTYPE" VARCHAR2(15 BYTE), 
	"BUDGET" NUMBER, 
	"CONTENT" VARCHAR2(4000 BYTE), 
	"COMPLETE" VARCHAR2(10 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.PROJECT
SET DEFINE OFF;
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (1,'금융상품 추천 어플리케이션 제작',to_date('22/01/01','RR/MM/DD'),to_date('22/06/01','RR/MM/DD'),'선행개발','앱 개발',20000000,'FinProSuggest: 금융상품 추천 어플리케이션은 사용자들에게 맞춤화된 금융상품을 추천하고 안내하는 개발 프로젝트입니다. 이 어플리케이션은 사용자의 금융 목표, 선호도, 위험 성향 등을 고려하여 최적의 금융상품을 추천하고, 투자, 대출, 저축 등 다양한 금융 분야에 대한 조언과 정보를 제공합니다. 금융상품 추천 어플리케이션은 사용자의 개인정보와 금융 데이터를 수집하여 분석하는 기능을 포함합니다. 사용자는 앱에 제공하는 설문이나 퀴즈를 통해 자신의 금융 상황과 선호도를 입력하고, 앱은 이를 기반으로 사용자 프로필을 작성합니다. 그런 다음, 이 프로필을 활용하여 다양한 금융상품 데이터베이스와 연동하여 최적의 상품을 추천합니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (2,'웹 크롤링 프로그램 제작',to_date('22/03/02','RR/MM/DD'),to_date('22/09/01','RR/MM/DD'),'양산개발','모바일개발',50000000,'WebCrawlPro: 웹 크롤링 프로그램은 인터넷 상의 웹 페이지를 자동으로 탐색하고 데이터를 수집하는 도구입니다. 이 프로그램은 사용자가 지정한 웹 사이트나 특정 페이지를 대상으로 웹 상의 정보를 수집하고, 필요한 데이터를 추출하여 저장 또는 분석할 수 있습니다. 웹 크롤링 프로그램은 다양한 언어와 라이브러리를 활용하여 개발할 수 있습니다. 대표적으로 Python과 그의 라이브러리인 BeautifulSoup, Scrapy 등이 널리 사용됩니다. 다른 언어로도 개발할 수 있으며, 선택한 언어에 따라 웹 크롤링 기능을 구현합니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (3,'POS프로그램 제작',to_date('22/03/02','RR/MM/DD'),to_date('22/09/01','RR/MM/DD'),'선행개발','앱 개발',25000000,'POSolution: POS(판매점 포인트 오브 세일) 프로그램은 판매점에서 제품 판매 및 관리를 효율적으로 수행하기 위한 소프트웨어입니다. 이 프로그램은 주로 소매업체, 음식점, 호텔, 슈퍼마켓 등에서 사용되며, 다양한 기능을 제공합니다. POS 프로그램은 판매 거래의 기록과 관리를 지원합니다. 제품의 판매를 기록하고 영수증을 발급함으로써 판매 거래 내역을 추적하고 관리할 수 있습니다. 이를 통해 매출 현황과 판매 분석에 도움이 되며, 재고 관리와 제품 구매에 대한 효율성을 높일 수 있습니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (4,'WebPlus: 웹 서버 개발 및 관리 프로그램 제작',to_date('22/01/01','RR/MM/DD'),to_date('22/06/01','RR/MM/DD'),'선행개발','앱 개발',50000000,'WebPlus는 사용자들에게 웹 서버 개발 및 관리를 간편하게 제공하는 프로젝트입니다. 이 프로젝트는 다양한 기술과 도구를 활용하여 사용자가 신속하고 안정적으로 웹 서버를 구축하고 관리할 수 있도록 지원합니다. WebPlus는 사용자가 웹 애플리케이션을 개발하고 배포하는 데 필요한 모든 단계를 포괄합니다. 이를 위해 사용자는 웹 서버의 설정, 데이터베이스 연결, 보안 설정, 사용자 인증 등을 간편한 인터페이스를 통해 설정할 수 있습니다. 또한, WebPlus는 성능 모니터링, 오류 로깅, 자동화된 배포 등의 기능을 제공하여 웹 서버의 안정성과 효율성을 향상시킵니다. WebPlus를 사용함으로써 개발자들은 웹 서버 관리에 소요되는 시간과 노력을 최소화하고, 보다 집중적으로 웹 애플리케이션의 개발과 기능 향상에 집중할 수 있습니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (5,'EduTechHub: 학습자들을 위한 온라인 교육 플랫폼',to_date('22/03/02','RR/MM/DD'),to_date('22/09/01','RR/MM/DD'),'양산개발','모바일개발',40000000,'EduTechHub은 학습자들을 위한 온라인 교육 플랫폼입니다. 사용자는 다양한 주제와 학습 자료를 탐색하고, 강의를 수강하며, 퀴즈와 과제를 제출할 수 있습니다. 또한, 학습 경로를 개인화하여 자신의 학습 목표에 맞게 진행할 수도 있습니다. EduTechHub은 사용자들이 효과적으로 학습할 수 있도록 다양한 학습 도구와 자원을 제공하며, 사용자들 간의 협력과 토론을 촉진합니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (6,' FoodieConnect: 음식 관련 소셜 네트워크 웹 애플리케이션',to_date('22/03/02','RR/MM/DD'),to_date('22/09/01','RR/MM/DD'),'선행개발','앱 개발',25000000,'FoodieConnect는 음식을 좋아하는 사람들을 위한 소셜 네트워크 웹 애플리케이션입니다. 사용자는 음식 사진을 업로드하고 레시피를 공유할 수 있으며, 다른 사용자의 음식 사진과 레시피를 찾아볼 수도 있습니다. 또한, 사용자들은 음식 관련 이벤트와 식당 추천을 공유하고 서로의 음식 경험에 대해 이야기할 수 있습니다. FoodieConnect는 음식을 좋아하는 사람들이 모여 정보를 공유하고 새로운 음식을 발견하는 데 도움을 주는 플랫폼입니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (7,'Webflix: 영화와 TV 프로그램을 검색하고 시청할 수 있는 웹 서비스',to_date('22/01/01','RR/MM/DD'),to_date('22/06/01','RR/MM/DD'),'선행개발','앱 개발',20000000,'Webflix는 사용자가 영화와 TV 프로그램을 검색하고 시청할 수 있는 웹 서비스입니다. 사용자는 로그인하여 즐겨 찾는 영화를 저장하고, 추천 영화를 받을 수 있습니다. 또한, 영화에 대한 평점과 리뷰를 작성하고 공유할 수 있으며, 다른 사용자의 리뷰를 읽어볼 수도 있습니다. Webflix는 사용자들에게 편리하고 유용한 영화 관련 서비스를 제공하여 시간을 보내는 동안 즐거움을 선사합니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (8,'AppGenius: 창의적인 모바일 앱 개발을 위해 의견을 공유할 수 있는 플랫폼',to_date('22/03/02','RR/MM/DD'),to_date('22/09/01','RR/MM/DD'),'선행개발','앱 개발',25000000,'AppGenius는 사용자들이 강력하고 창의적인 모바일 애플리케이션을 개발할 수 있는 개발 프로젝트입니다. 이 프로젝트는 사용자에게 직관적인 인터페이스와 다양한 기능을 제공하여 앱 개발 프로세스를 간소화하고 향상시킵니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (9,'ServeItUp: 웹 서버 개발 프로젝트',to_date('22/03/02','RR/MM/DD'),to_date('22/09/01','RR/MM/DD'),'선행개발','앱 개발',25000000,'웹 서버 개발 프로젝트인 "ServeItUp"은 고성능이며 확장 가능한 웹 서버를 개발하는 것을 목표로 합니다. 이 프로젝트는 클라이언트의 요청에 응답하고 웹 페이지, 파일, 데이터 등을 제공하는 기능을 구현하는 데 중점을 둡니다. ServeItUp은 다양한 프로그래밍 언어와 프레임워크를 활용하여 개발됩니다. 주요 기능으로는 HTTP 요청 처리, 정적 및 동적 콘텐츠 제공, 세션 관리, 보안 기능 등이 포함됩니다. 또한, 다중 스레드 또는 비동기 방식을 활용하여 동시 다발적인 요청 처리에 대비하며, 효율적인 리소스 관리와 성능 최적화를 지향합니다.','완료');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',to_date('23/03/02','RR/MM/DD'),to_date('23/09/01','RR/MM/DD'),'양산개발','모바일개발',50000000,'WebForge는 사용자들이 웹 서버를 구축하고 관리하는 데 필요한 도구와 기능을 제공하는 개발 프로젝트입니다. 사용자는 직관적인 인터페이스를 통해 웹 서버 설정, 데이터베이스 연동, 보안 설정 등을 손쉽게 수행할 수 있으며, 확장성과 안정성을 갖춘 웹 애플리케이션을 개발할 수 있습니다.','진행중');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (27,'spring프로젝트',to_date('23/06/04','RR/MM/DD'),to_date('23/06/21','RR/MM/DD'),'양산개발','앱 개발',11111111,'spring프로젝트','n');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (25,'PMS 프로젝트',to_date('23/06/12','RR/MM/DD'),to_date('23/06/13','RR/MM/DD'),'선행개발','앱 개발',10000000,'PMS 프로젝트입니다.','n');
Insert into TEAM.PROJECT (PROJECTSEQ,NAME,STARTDATE,ENDDATE,PROJECTTYPE,RNDTYPE,BUDGET,CONTENT,COMPLETE) values (26,'jsp프로젝트',to_date('23/06/05','RR/MM/DD'),to_date('23/06/24','RR/MM/DD'),'양산개발','앱 개발',11111111,'jsp프로젝트입니다.','n');
--------------------------------------------------------
--  DDL for Index SYS_C008997
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C008997" ON "TEAM"."PROJECT" ("PROJECTSEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table PROJECT
--------------------------------------------------------

  ALTER TABLE "TEAM"."PROJECT" ADD PRIMARY KEY ("PROJECTSEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("COMPLETE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("BUDGET" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("RNDTYPE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("PROJECTTYPE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("ENDDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("STARTDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PROJECT" MODIFY ("PROJECTSEQ" NOT NULL ENABLE);
