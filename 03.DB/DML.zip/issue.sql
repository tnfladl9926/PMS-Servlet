--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ISSUE
--------------------------------------------------------

  CREATE TABLE "TEAM"."ISSUE" 
   (	"ISSUESEQ" NUMBER, 
	"TITLE" VARCHAR2(100 BYTE), 
	"ISSUETYPE" VARCHAR2(100 BYTE), 
	"ISSUEDATE" DATE DEFAULT sysdate, 
	"DEADLINE" DATE, 
	"STATUS" VARCHAR2(10 BYTE) DEFAULT 'w', 
	"ISSUECONTENT" VARCHAR2(4000 BYTE), 
	"PROJECTSEQ" NUMBER, 
	"EMPLOYEESEQ" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.ISSUE
SET DEFINE OFF;
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (1,'새로운 기능 추가','승인신청',to_date('22/03/10','RR/MM/DD'),to_date('22/03/14','RR/MM/DD'),'y','프로젝트 기능 추가 목록 확인 부탁드립니다.',1,3);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (2,'소스 코드 오류','일정지연',to_date('22/05/11','RR/MM/DD'),to_date('22/05/13','RR/MM/DD'),'y','수정한 소스 코드 확인 부탁드립니다.',1,2);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (3,'수정사항 검토','승인신청',to_date('22/03/04','RR/MM/DD'),to_date('22/03/05','RR/MM/DD'),'y','수정사항 반영한 파일 업로드 확인 부탁드립니다.',1,4);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (4,'테스트 진행 검토','승인신청',to_date('22/05/18','RR/MM/DD'),to_date('22/05/22','RR/MM/DD'),'y','테스트 진행 후 검토사항입니다.',1,5);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (5,'고객 요구사항 추가','승인신청',to_date('22/03/22','RR/MM/DD'),to_date('22/03/23','RR/MM/DD'),'y','고객 요구사항 추가사항 부탁드립니다.',2,7);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (6,'소스 코드 오류','일정지연',to_date('22/05/15','RR/MM/DD'),to_date('22/05/17','RR/MM/DD'),'y','수정한 소스 코드 확인 부탁드립니다.',2,8);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (7,'일정 연기 확인','일정지연',to_date('22/06/11','RR/MM/DD'),to_date('22/06/20','RR/MM/DD'),'y','회의 참석으로 인한 일정연기  확인 부탁드립니다.',2,10);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (8,'금일 회의 후 수정사항 반영','승인신청',to_date('22/08/09','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'),'y','회의 후 수정사항 반영한 파일 확인 부탁드립니다.',2,9);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (9,'고객 변심건 확인 요청','고객변심',to_date('22/04/15','RR/MM/DD'),to_date('22/04/19','RR/MM/DD'),'y','고객 변심건 확인 부탁드립니다.',3,13);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (10,'일정 지연 확인요청','일정지연',to_date('22/05/24','RR/MM/DD'),to_date('22/05/26','RR/MM/DD'),'y','고객 변심건으로 인한 일정 연기 확인부탁드립니다.',3,12);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (11,'리소스 수정사항 확인','승인신청',to_date('22/07/11','RR/MM/DD'),to_date('22/07/15','RR/MM/DD'),'y','리소스 수정사항 확인 부탁드립니다.',3,14);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (12,'검토 리스트 수정','승인신청',to_date('22/08/05','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),'y','검토 리스트 수정 확인 부탁드립니다.',3,15);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (14,'고객변심 이슈입니다.','고객변심',to_date('23/06/09','RR/MM/DD'),to_date('23/06/12','RR/MM/DD'),'y','확인 부탁드립니다. ddfd',1,2);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (15,'추가 수정사항입니다.','고객변심',to_date('23/06/10','RR/MM/DD'),to_date('23/06/17','RR/MM/DD'),'y','클라이언트 요청입니다. 확인부탁드립니다.',1,2);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (16,'새로운 기능 추가','승인신청',to_date('22/03/10','RR/MM/DD'),to_date('22/03/14','RR/MM/DD'),'y','프로젝트 기능 추가 목록 확인 부탁드립니다.',4,16);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (17,'소스 코드 오류','일정지연',to_date('22/05/11','RR/MM/DD'),to_date('22/05/13','RR/MM/DD'),'y','수정한 소스 코드 확인 부탁드립니다.',4,17);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (18,'테스트 진행 검토','승인신청',to_date('22/05/18','RR/MM/DD'),to_date('22/05/22','RR/MM/DD'),'w','테스트 진행 후 검토사항입니다.',4,19);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (19,'고객 요구사항 추가','승인신청',to_date('22/03/22','RR/MM/DD'),to_date('22/03/23','RR/MM/DD'),'y','고객 요구사항 추가사항 부탁드립니다.',5,21);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (20,'소스 코드 오류','일정지연',to_date('22/05/15','RR/MM/DD'),to_date('22/05/17','RR/MM/DD'),'y','수정한 소스 코드 확인 부탁드립니다.',5,22);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (21,'일정 연기 확인','일정지연',to_date('22/06/11','RR/MM/DD'),to_date('22/06/20','RR/MM/DD'),'w','회의 참석으로 인한 일정연기  확인 부탁드립니다.',5,23);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (22,'금일 회의 후 수정사항 반영','승인신청',to_date('22/08/09','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'),'y','회의 후 수정사항 반영한 파일 확인 부탁드립니다.',5,24);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (23,'고객 변심건 확인 요청','고객변심',to_date('22/04/15','RR/MM/DD'),to_date('22/04/19','RR/MM/DD'),'y','고객 변심건 확인 부탁드립니다.',6,26);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (24,'일정 지연 확인요청','일정지연',to_date('22/05/24','RR/MM/DD'),to_date('22/05/26','RR/MM/DD'),'y','고객 변심건으로 인한 일정 연기 확인부탁드립니다.',6,27);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (25,'리소스 수정사항 확인','승인신청',to_date('22/07/11','RR/MM/DD'),to_date('22/07/15','RR/MM/DD'),'y','리소스 수정사항 확인 부탁드립니다.',6,28);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (26,'검토 리스트 수정','승인신청',to_date('22/08/05','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),'y','검토 리스트 수정 확인 부탁드립니다.',6,29);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (27,'새로운 기능 추가','승인신청',to_date('22/03/10','RR/MM/DD'),to_date('22/03/14','RR/MM/DD'),'w','프로젝트 기능 추가 목록 확인 부탁드립니다.',7,31);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (28,'소스 코드 오류','일정지연',to_date('22/05/11','RR/MM/DD'),to_date('22/05/13','RR/MM/DD'),'y','수정한 소스 코드 확인 부탁드립니다.',7,32);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (29,'수정사항 검토','승인신청',to_date('22/03/04','RR/MM/DD'),to_date('22/03/05','RR/MM/DD'),'y','수정사항 반영한 파일 업로드 확인 부탁드립니다.',7,33);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (30,'테스트 진행 검토','승인신청',to_date('22/05/18','RR/MM/DD'),to_date('22/05/22','RR/MM/DD'),'w','테스트 진행 후 검토사항입니다.',7,34);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (31,'고객 요구사항 추가','승인신청',to_date('22/03/22','RR/MM/DD'),to_date('22/03/23','RR/MM/DD'),'y','고객 요구사항 추가사항 부탁드립니다.',8,36);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (32,'소스 코드 오류','일정지연',to_date('22/05/15','RR/MM/DD'),to_date('22/05/17','RR/MM/DD'),'w','수정한 소스 코드 확인 부탁드립니다.',8,37);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (33,'일정 연기 확인','일정지연',to_date('22/06/11','RR/MM/DD'),to_date('22/06/20','RR/MM/DD'),'y','회의 참석으로 인한 일정연기  확인 부탁드립니다.',8,38);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (34,'금일 회의 후 수정사항 반영','승인신청',to_date('22/08/09','RR/MM/DD'),to_date('22/08/17','RR/MM/DD'),'y','회의 후 수정사항 반영한 파일 확인 부탁드립니다.',8,39);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (35,'고객 변심건 확인 요청','고객변심',to_date('22/04/15','RR/MM/DD'),to_date('22/04/19','RR/MM/DD'),'y','고객 변심건 확인 부탁드립니다.',9,41);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (36,'일정 지연 확인요청','일정지연',to_date('22/05/24','RR/MM/DD'),to_date('22/05/26','RR/MM/DD'),'w','고객 변심건으로 인한 일정 연기 확인부탁드립니다.',9,42);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (37,'리소스 수정사항 확인','승인신청',to_date('22/07/11','RR/MM/DD'),to_date('22/07/15','RR/MM/DD'),'y','리소스 수정사항 확인 부탁드립니다.',9,43);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (38,'검토 리스트 수정','승인신청',to_date('22/08/05','RR/MM/DD'),to_date('22/08/11','RR/MM/DD'),'y','검토 리스트 수정 확인 부탁드립니다.',9,44);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (39,'고객 변심건 확인 요청','고객변심',to_date('23/03/02','RR/MM/DD'),to_date('22/04/19','RR/MM/DD'),'w','고객 변심건 확인 부탁드립니다.',10,2);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (40,'일정 지연 확인요청','일정지연',to_date('23/04/24','RR/MM/DD'),to_date('23/05/26','RR/MM/DD'),'y','고객 변심건으로 인한 일정 연기 확인부탁드립니다.',10,3);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (41,'리소스 수정사항 확인','승인신청',to_date('23/07/11','RR/MM/DD'),to_date('22/07/15','RR/MM/DD'),'w','리소스 수정사항 확인 부탁드립니다.',10,4);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (42,'검토 리스트 수정','승인신청',to_date('23/08/05','RR/MM/DD'),to_date('23/09/01','RR/MM/DD'),'y','검토 리스트 수정 확인 부탁드립니다.',10,5);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (43,'수정사항 검토','승인신청',to_date('22/03/04','RR/MM/DD'),to_date('22/03/05','RR/MM/DD'),'y','수정사항 반영한 파일 업로드 확인 부탁드립니다.',4,18);
Insert into TEAM.ISSUE (ISSUESEQ,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,STATUS,ISSUECONTENT,PROJECTSEQ,EMPLOYEESEQ) values (44,'수정사항 확인','고객변심',to_date('23/06/12','RR/MM/DD'),to_date('23/06/12','RR/MM/DD'),'w','이슈 확인 부탁드립니다.',4,2);
--------------------------------------------------------
--  DDL for Index SYS_C008941
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C008941" ON "TEAM"."ISSUE" ("ISSUESEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table ISSUE
--------------------------------------------------------

  ALTER TABLE "TEAM"."ISSUE" ADD PRIMARY KEY ("ISSUESEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("EMPLOYEESEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("PROJECTSEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("ISSUECONTENT" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("DEADLINE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("ISSUEDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("ISSUETYPE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("TITLE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."ISSUE" MODIFY ("ISSUESEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table ISSUE
--------------------------------------------------------

  ALTER TABLE "TEAM"."ISSUE" ADD FOREIGN KEY ("EMPLOYEESEQ")
	  REFERENCES "TEAM"."EMPLOYEE" ("EMPLOYEESEQ") ENABLE;
