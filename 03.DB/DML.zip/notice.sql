--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table NOTICE
--------------------------------------------------------

  CREATE TABLE "TEAM"."NOTICE" 
   (	"NOTICESEQ" NUMBER, 
	"TITLE" VARCHAR2(100 BYTE), 
	"NOTICEDATE" DATE DEFAULT sysdate, 
	"CONTENT" VARCHAR2(4000 BYTE), 
	"NOTICETYPE" VARCHAR2(10 BYTE), 
	"EMPLOYEESEQ" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.NOTICE
SET DEFINE OFF;
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (1,'보안 강화 조치 안내',to_date('22/03/30','RR/MM/DD'),'안녕하세요, 최근 사이버 보안에 대한 위협이 증가하고 있어 저희 회사의 보안을 강화하기 위해 몇 가지 조치를 취하고자 합니다. 모든 직원은 비밀번호를 정기적으로 변경해야 하며, 강력한 암호 조합을 사용해야 합니다. 또한, 외부 이메일의 첨부 파일을 열거나 의심스러운 링크를 클릭하지 말아주시기 바랍니다. 보안에 대한 자세한 안내는 IT부서에서 이메일을 통해 제공될 예정입니다. 협조해 주시기 바랍니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (2,'근로시간 조정 안내',to_date('22/04/10','RR/MM/DD'),'안녕하세요, 모든 직원 여러분께 알려드립니다. 최근 업무 부담이 증가하였고, 직원들의 근로 시간을 더욱 효율적으로 조정하기 위해 시간 조정 정책을 도입하게 되었습니다. 이에 따라 출근 시간이 조정되었으니, 개별적으로 업무 담당자와 상의하여 변경된 근로시간에 맞춰 출퇴근하시기 바랍니다. 이 조치는 업무 집중도와 생산성 향상을 위함이니 많은 협조 부탁드립니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (3,'사내 인트라넷 서비스 개선 안내',to_date('22/04/15','RR/MM/DD'),'안녕하세요, 저희 회사의 내부 커뮤니케이션 및 정보 공유를 원활하게 하기 위해 사내 인트라넷 서비스를 개선하였습니다. 새로운 기능과 사용자 친화적인 인터페이스가 도입되었으며, 사내 문서, 공지사항, 프로젝트 정보 등을 효율적으로 관리할 수 있습니다. 모든 직원은 개인 계정으로 로그인하여 서비스를 이용하실 수 있습니다. 자세한 사용법과 접속 방법은 IT부서에서 안내해 드릴 예정입니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (4,'휴가 신청 절차 변경 안내',to_date('22/05/11','RR/MM/DD'),'안녕하세요, HR팀입니다. 휴가 신청 절차에 변경이 있었음을 알려드립니다. 이제부터 휴가 신청은 사내 인트라넷의 "휴가 신청" 메뉴를 통해 온라인으로 진행하셔야 합니다. 이전처럼 종이로 작성하여 제출하는 방식은 사용되지 않을 예정이니 참고하시기 바랍니다. 휴가 신청 방법과 절차에 대한 상세 안내는 인트라넷에서 확인하실 수 있습니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (5,'네트워크 점검 예정 안내',to_date('22/06/07','RR/MM/DD'),'안녕하세요, IT부서입니다. 네트워크 시스템의 안정성을 확보하기 위해 정기적인 점검을 실시할 예정입니다. 점검 일정은 다음과 같습니다: 일자: 2022년 3월 15일 (화요일). 시간: 오전 9시부터 오후 1시까지. 점검 중에는 네트워크 연결이 일시적으로 중단될 수 있으므로, 업무에 참고하시기 바랍니다. 점검이 완료되면 시스템이 정상적으로 복구될 것입니다. 혹시 점검에 관련하여 궁금한 사항이 있으시면 IT부서로 문의해 주세요. 감사합니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (6,'사내 행사 안내 - 기업 송년 파티',to_date('22/11/30','RR/MM/DD'),'안녕하세요, 회사 행사 담당자입니다. 올해의 마무리를 잘 맞이하고자 기업 송년 파티를 개최할 예정입니다. 날짜는 12월 20일(목) 오후 6시부터 진행될 예정이며, 장소는 본사 식당입니다. 음식과 음료가 제공되며, 간단한 이벤트와 추첨을 통해 상품도 준비되어 있습니다. 참석 여부를 12월 10일까지 행사 담당자에게 알려주시기 바랍니다. 많은 참석 부탁드립니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (7,'급여 정산 일정 안내',to_date('22/12/15','RR/MM/DD'),'이번 달 급여 정산은 다음 주 금요일에 이루어질 예정입니다. 급여 관련 문의 사항은 인사팀으로 연락해주세요.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (8,'신입사원 교육 일정 공지',to_date('23/02/04','RR/MM/DD'),'신입사원 교육이 다음 주 월요일부터 시작됩니다. 모든 신입사원은 정해진 장소에 모여주세요.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (9,'긴급 서버 점검 안내',to_date('23/04/08','RR/MM/DD'),'긴급 서버 점검이 예정되어 있습니다. 점검 시간 동안 일시적으로 서비스 이용이 불가능할 수 있습니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (10,'사내 홍보 행사 일정 안내',to_date('23/05/13','RR/MM/DD'),'사내 홍보 행사가 다음 달에 열릴 예정입니다. 행사에 참석하고 싶은 분들은 사전에 등록해주시기 바랍니다. 확인 부탁드립니다.','전체',100);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (11,'주간 진행 상황 보고 안내',to_date('22/01/10','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분! 이번 주에는 우리 프로젝트의 진행 상황을 공유하고자 합니다. 모든 팀원은 자신이 맡은 업무에 대한 진행 상황을 사내 메신저를 통해 보고해주시길 바랍니다. 감사합니다.','팀별',1);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (12,'변경 사항 관련 미팅 일정 안내',to_date('22/02/28','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분! 중요한 변경 사항에 대한 논의를 위해 미팅을 예정하였습니다. 다음은 미팅 일정입니다. 일자: 2022년 3월 20일 (월요일). 시간: 오전 10시. 장소: 회의실 A. 모든 팀원은 해당 일정에 참석하여 변경 사항에 대한 의견을 공유하고, 필요한 조치 사항을 논의해 주시기 바랍니다. 미팅 준비물이 있는 경우 미리 준비하여 참석해 주세요. 혹시 일정 상 충돌이 있거나 참석에 어려움이 있는 경우 미리 연락해 주시기 바랍니다. 이상으로 공지사항 마치겠습니다. 감사합니다.','팀별',1);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (13,'팀 내 커뮤니케이션 도구 변경 안내',to_date('22/03/05','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분. 저희 팀의 커뮤니케이션 도구를 변경하기로 결정되었습니다. 기존에 사용하던 채팅 앱에서 프로젝트 관리 및 협업을 더욱 효율적으로 진행할 수 있는 플랫폼으로 전환합니다. 변경된 도구에 대한 사용법 및 접근 방법은 따로 안내드리겠습니다. 변경 사항에 대한 이해와 협조를 부탁드리며, 새로운 도구를 통해 더 원활한 소통과 협업을 이루어나가길 기대합니다. 추가 문의사항이 있으면 언제든지 문의해주세요. 감사합니다.','팀별',1);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (14,'작업 우선순위 조정 안내',to_date('22/04/27','RR/MM/DD'),'팀 내 작업의 우선순위가 조정되었습니다. 각 팀원은 새로운 우선순위에 따라 작업을 조정해야 합니다.','팀별',1);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (15,'클라이언트 미팅 날짜 변경 안내',to_date('22/05/15','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분. 7월 20일로 예정되어있던 클라이언트 미팅이 7월 23일로 변경되었음을 알려드립니다. 감사합니다.','팀별',1);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (16,'주간 진행 상황 보고 안내',to_date('22/03/10','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분! 이번 주에는 우리 프로젝트의 진행 상황을 공유하고자 합니다. 모든 팀원은 자신이 맡은 업무에 대한 진행 상황을 사내 메신저를 통해 보고해주시길 바랍니다. 감사합니다.','팀별',6);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (17,'변경 사항 관련 미팅 일정 안내',to_date('22/03/28','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분! 중요한 변경 사항에 대한 논의를 위해 미팅을 예정하였습니다. 다음은 미팅 일정입니다. 일자: 2022년 3월 20일 (월요일). 시간: 오전 10시. 장소: 회의실 A. 모든 팀원은 해당 일정에 참석하여 변경 사항에 대한 의견을 공유하고, 필요한 조치 사항을 논의해 주시기 바랍니다. 미팅 준비물이 있는 경우 미리 준비하여 참석해 주세요. 혹시 일정 상 충돌이 있거나 참석에 어려움이 있는 경우 미리 연락해 주시기 바랍니다. 감사합니다.','팀별',6);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (18,'팀 내 커뮤니케이션 도구 변경 안내',to_date('22/04/05','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분. 저희 팀의 커뮤니케이션 도구를 변경하기로 결정되었습니다. 기존에 사용하던 채팅 앱에서 프로젝트 관리 및 협업을 더욱 효율적으로 진행할 수 있는 플랫폼으로 전환합니다. 변경된 도구에 대한 사용법 및 접근 방법은 따로 안내드리겠습니다. 변경 사항에 대한 이해와 협조를 부탁드리며, 새로운 도구를 통해 더 원활한 소통과 협업을 이루어나가길 기대합니다. 추가 문의사항이 있으면 언제든지 문의해주세요. 감사합니다.','팀별',6);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (19,'작업 우선순위 조정 안내',to_date('22/05/27','RR/MM/DD'),'팀 내 작업의 우선순위가 조정되었습니다. 각 팀원은 새로운 우선순위에 따라 작업을 조정해야 합니다.','팀별',6);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (20,'클라이언트 미팅 날짜 변경 안내',to_date('22/07/15','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분. 7월 20일로 예정되어있던 클라이언트 미팅이 7월 23일로 변경되었음을 알려드립니다. 감사합니다.','팀별',6);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (21,'주간 진행 상황 보고 안내',to_date('22/03/10','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분! 이번 주에는 우리 프로젝트의 진행 상황을 공유하고자 합니다. 모든 팀원은 자신이 맡은 업무에 대한 진행 상황을 사내 메신저를 통해 보고해주시길 바랍니다. 감사합니다.','팀별',11);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (22,'변경 사항 관련 미팅 일정 안내',to_date('22/03/28','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분! 중요한 변경 사항에 대한 논의를 위해 미팅을 예정하였습니다. 다음은 미팅 일정입니다. 일자: 2022년 3월 20일 (월요일). 시간: 오전 10시. 장소: 회의실 A. 모든 팀원은 해당 일정에 참석하여 변경 사항에 대한 의견을 공유하고, 필요한 조치 사항을 논의해 주시기 바랍니다. 미팅 준비물이 있는 경우 미리 준비하여 참석해 주세요. 혹시 일정 상 충돌이 있거나 참석에 어려움이 있는 경우 미리 연락해 주시기 바랍니다. 감사합니다.','팀별',11);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (23,'팀 내 커뮤니케이션 도구 변경 안내',to_date('22/04/05','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분. 저희 팀의 커뮤니케이션 도구를 변경하기로 결정되었습니다. 기존에 사용하던 채팅 앱에서 프로젝트 관리 및 협업을 더욱 효율적으로 진행할 수 있는 플랫폼으로 전환합니다. 변경된 도구에 대한 사용법 및 접근 방법은 따로 안내드리겠습니다. 변경 사항에 대한 이해와 협조를 부탁드리며, 새로운 도구를 통해 더 원활한 소통과 협업을 이루어나가길 기대합니다. 추가 문의사항이 있으면 언제든지 문의해주세요. 감사합니다.','팀별',11);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (24,'작업 우선순위 조정 안내',to_date('22/05/27','RR/MM/DD'),'팀 내 작업의 우선순위가 조정되었습니다. 각 팀원은 새로운 우선순위에 따라 작업을 조정해야 합니다.','팀별',11);
Insert into TEAM.NOTICE (NOTICESEQ,TITLE,NOTICEDATE,CONTENT,NOTICETYPE,EMPLOYEESEQ) values (25,'클라이언트 미팅 날짜 변경 안내',to_date('22/07/15','RR/MM/DD'),'안녕하세요, 프로젝트 팀원 여러분. 7월 20일로 예정되어있던 클라이언트 미팅이 7월 23일로 변경되었음을 알려드립니다. 감사합니다.','팀별',11);
--------------------------------------------------------
--  DDL for Index SYS_C008981
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C008981" ON "TEAM"."NOTICE" ("NOTICESEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table NOTICE
--------------------------------------------------------

  ALTER TABLE "TEAM"."NOTICE" ADD PRIMARY KEY ("NOTICESEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."NOTICE" MODIFY ("EMPLOYEESEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."NOTICE" MODIFY ("NOTICETYPE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."NOTICE" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."NOTICE" MODIFY ("NOTICEDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."NOTICE" MODIFY ("TITLE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."NOTICE" MODIFY ("NOTICESEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table NOTICE
--------------------------------------------------------

  ALTER TABLE "TEAM"."NOTICE" ADD FOREIGN KEY ("EMPLOYEESEQ")
	  REFERENCES "TEAM"."EMPLOYEE" ("EMPLOYEESEQ") ENABLE;
