--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table REGISTER
--------------------------------------------------------

  CREATE TABLE "TEAM"."REGISTER" 
   (	"ID" VARCHAR2(30 BYTE), 
	"PW" VARCHAR2(30 BYTE), 
	"EMPLOYEESEQ" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.REGISTER
SET DEFINE OFF;
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('hong','1111',1);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('wogus9610','1111',2);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('shjeewg','6mti812v',3);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ajwyalw','8ym0fka1',4);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('qbdzyfd','lzwx5kj0',5);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ssipvbl','fnb626ic',6);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('zzbvoec','ddflivs6',7);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('dgnrouk','qzx7cguo',8);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('acfayly','7tw9ixqk',9);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('pgfzeeg','v6ghkya9',10);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('kbyltmk','0y6pybhm',11);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ahifpfg','eta9v73r',12);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rcysfzl','bvolf86s',13);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('xhdbjvp','jj2t8hvm',14);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('utkpruv','b8tog8mt',15);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ivsrfon','jdudmiep',16);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ihidxfr','djj4vcwy',17);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rmbsjik','esxpd466',18);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('mnqoecp','429jb1t6',19);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('jcpoutr','6gl28si5',20);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('hdoxlis','27oz6p5o',21);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('nunlaro','1vw1anii',22);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('lcisedv','sysym1hx',23);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('raeitee','oqhj23ys',24);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('xojtcjh','tut3pbsw',25);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ypavzrw','by1kvb7x',26);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('xixpxzr','6ie0ywdl',27);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('dmxvmki','gy9yx18r',28);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bdagciw','n8bnbnwx',29);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('llifhpw','om291hgg',30);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bidxzqy','mw8g6cj3',31);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('skbuykq','99h68cc5',32);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('kuqobqg','tj9ls4f5',33);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('inqiyjq','se3k85gz',34);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('pkfsxfg','1cy1ca80',35);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('djwttsr','lc7jv0v4',36);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('iydneff','ocotpkel',37);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ffirhow','hs3jnut9',38);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ubbnnnr','11of440n',39);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('jznjuba','exnjn5bx',40);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('tsdjqyw','dtt3wsx3',41);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('lfupbpa','syw9i28q',42);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('aeducsc','f1sm6kui',43);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('lweqllo','43o4q69j',44);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ogcsknp','hlii9fan',45);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('hefaqtt','el7v369r',46);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('nimqbpa','4pvccw9e',47);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('peajxsc','icecfdic',48);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ycwbuyv','8255wmj5',49);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('kbwdvno','k0s2yhkh',50);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rgxbkid','3ppdrx9y',51);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('lzcyvpl','ibs6n0pn',52);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ikfvozx','h4qmwlmv',53);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bmzfsph','1ppq7euu',54);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bgwcyfl','y5fas073',55);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('xbfcyrk','arv6z9xu',56);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('dpqsoek','q2s6ceqn',57);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('wmtpvzc','07ttgwdd',58);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('dnkfnrk','jyljg3gj',59);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('wywaqxs','f2tve6ay',60);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('heddnir','fllnwabx',61);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('wgdqozl','s7okkqr1',62);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('dyqgbeu','2cipwlzq',63);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('npnsbxw','xrlyk5tr',64);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('pnljaro','xx47eluy',65);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('deoapok','hgize813',66);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('qwvtuyy','vg9se8oy',67);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rzkibhn','jo0i041e',68);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ejenfas','7c0ibvrm',69);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rjcwepi','heo2329y',70);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ogbmfck','nykzlv12',71);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('eeekprw','n301ikjr',72);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('myldwyu','7oyjzmgj',73);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('iekyine','pyb13nig',74);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('edijwci','l0fugaq0',75);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('xmpbnzz','9t5ulwj4',76);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ksepbqm','3tuw9g8r',77);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bmucuym','3lptxewv',78);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('wkjysne','ij7ac9tx',79);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('nqapjch','vgkwws57',80);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('gqsevpc','7jw6fhtg',81);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('ndyihuv','ru7q5u1c',82);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('sjbwlvi','r0ijbunv',83);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('gdzezgo','k2pr275s',84);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('dnlydgp','qlqptqj3',85);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('scbkbyh','uzsiejx0',86);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bltzgne','mgkiwqjb',87);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('vqhhfak','btipcjqe',88);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('zwxdrhh','uyrt19d5',89);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('roiaznm','i8b4pxrh',90);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('grornnv','ior3kq85',91);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rewnaxt','1dipe1yt',92);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('bqdifqc','de06htyc',93);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('mnigfgq','d3ohogs4',94);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('jkpvvxf','4foi40u0',95);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('cqxmhwp','j1dxdyox',96);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('fgvsnwv','v2lb5ulq',97);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('oqvelhy','qte6h6pe',98);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rtfcrgu','9hamyevq',99);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('rywdsdv','51g1fgkn',100);
Insert into TEAM.REGISTER (ID,PW,EMPLOYEESEQ) values ('wlstjq9610','1111',109);
--------------------------------------------------------
--  DDL for Index SYS_C008922
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C008922" ON "TEAM"."REGISTER" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table REGISTER
--------------------------------------------------------

  ALTER TABLE "TEAM"."REGISTER" ADD PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."REGISTER" MODIFY ("EMPLOYEESEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."REGISTER" MODIFY ("PW" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."REGISTER" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table REGISTER
--------------------------------------------------------

  ALTER TABLE "TEAM"."REGISTER" ADD FOREIGN KEY ("EMPLOYEESEQ")
	  REFERENCES "TEAM"."EMPLOYEE" ("EMPLOYEESEQ") ENABLE;
