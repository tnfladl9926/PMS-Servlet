--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PRODUCT
--------------------------------------------------------

  CREATE TABLE "TEAM"."PRODUCT" 
   (	"PRODUCTSEQ" NUMBER, 
	"PRODUCTNAME" VARCHAR2(200 BYTE), 
	"CONTENT" VARCHAR2(4000 BYTE), 
	"PRODUCTDATE" DATE DEFAULT sysdate, 
	"EMPLOYEESEQ" NUMBER, 
	"PROJECTSEQ" NUMBER
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into TEAM.PRODUCT
SET DEFINE OFF;
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (1,'금융 프로젝트 요구사항 명세서','금융 프로젝트 요구사항에 대한 명세서입니다.',to_date('22/01/09','RR/MM/DD'),1,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (2,'금융 프로젝트 기술 명세서','금융 프로젝트 기술 명세서입니다.',to_date('22/02/10','RR/MM/DD'),1,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (3,'금융 프로젝트 화면 설계서','금융 프로젝트 화면 설계서입니다.',to_date('22/03/15','RR/MM/DD'),2,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (4,'금융 프로젝트 데이터베이스 설계서','금융 프로젝트 데이터베이스 설계서입니다.',to_date('22/03/25','RR/MM/DD'),2,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (5,'금융 프로젝트 소스코드','금융 프로젝트 소스코드입니다.',to_date('22/04/20','RR/MM/DD'),3,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (6,'금융 프로젝트 위험 관리 계획서','금융 프로젝트 위험 관리 계획서입니다.',to_date('22/04/30','RR/MM/DD'),3,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (7,'금융 프로젝트 변경 제어 문서','금융 프로젝트 변경 제어 문서입니다.',to_date('22/05/15','RR/MM/DD'),4,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (8,'금융 프로젝트 보고서','금융 프로젝트 보고서 산출물입니다.',to_date('22/05/28','RR/MM/DD'),4,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (9,'금융 프로젝트 배포 및 운영 문서','금융 프로젝트 배포 및 운영 문서입니다.',to_date('22/05/31','RR/MM/DD'),5,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (10,'금융 프로젝트 유지 보수 문서','금융 프로젝트 유지 보수 문서입니다.',to_date('22/06/01','RR/MM/DD'),5,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (11,'크롤링 프로그램 요구사항 명세서','크롤링 프로그램 요구사항 명세서입니다.',to_date('22/03/15','RR/MM/DD'),6,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (12,'크롤링 프로그램 기술 명세서','크롤링 프로그램 기술 명세서입니다.',to_date('22/03/23','RR/MM/DD'),6,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (13,'크롤링 프로그램 화면 설계서','크롤링 프로그램 화면 설계서입니다.',to_date('22/04/05','RR/MM/DD'),7,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (14,'크롤링 프로그램 데이터베이스 설계서','크롤링 프로그램 데이터베이스 설계서입니다.',to_date('22/04/26','RR/MM/DD'),7,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (15,'크롤링 프로그램 소스코드','크롤링 프로그램 소스코드입니다.',to_date('22/07/18','RR/MM/DD'),8,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (16,'크롤링 프로그램 위험 관리 계획서','크롤링 프로그램 위험 관리 계획서입니다.',to_date('22/07/27','RR/MM/DD'),8,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (17,'크롤링 프로그램 변경 제어 문서','크롤링 프로그램 변경 제어 문서입니다.',to_date('22/08/11','RR/MM/DD'),9,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (18,'크롤링 프로그램 보고서','크롤링 프로그램 보고서입니다.',to_date('22/08/13','RR/MM/DD'),9,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (19,'크롤링 프로그램 배포 및 운영 문서','크롤링 프로그램 배포 및 운영 문서입니다.',to_date('22/08/17','RR/MM/DD'),10,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (20,'크롤링 프로그램 유지 보수 문서','크롤링 프로그램 유지 보수 문서입니다.',to_date('22/09/01','RR/MM/DD'),10,2);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (21,'POS프로그램 요구사항 명세서','POS프로그램 유지 보수 문서입니다.',to_date('22/03/15','RR/MM/DD'),11,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (22,'POS프로그램 기술 명세서','POS프로그램 기술 명세서입니다.',to_date('22/03/23','RR/MM/DD'),11,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (23,'POS프로그램 화면 설계서','POS프로그램 화면 설계서입니다.',to_date('22/04/05','RR/MM/DD'),12,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (24,'POS프로그램 데이터베이스 설계서','POS프로그램 데이터베이스 설계서입니다.',to_date('22/04/26','RR/MM/DD'),12,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (25,'POS프로그램 소스코드','POS프로그램 소스코드입니다.',to_date('22/07/18','RR/MM/DD'),13,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (26,'POS프로그램 위험 관리 계획서','POS프로그램 위험 관리 계획서입니다.',to_date('22/07/27','RR/MM/DD'),13,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (27,'POS프로그램 변경 제어 문서','POS프로그램 변경 제어 문서입니다.',to_date('22/08/11','RR/MM/DD'),14,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (28,'POS프로그램 보고서','POS프로그램 보고서입니다.',to_date('22/08/13','RR/MM/DD'),14,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (29,'POS프로그램 배포 및 운영 문서','POS프로그램 배포 및 운영 문서입니다.',to_date('22/08/17','RR/MM/DD'),15,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (30,'POS프로그램 유지 보수 문서','POS프로그램 유지 보수 문서입니다.',to_date('22/09/01','RR/MM/DD'),15,3);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (31,'WebForge: 요구사항 명세서','요구사항 명세서는 프로젝트의 목적과 범위, 사용자 및 시스템 요구사항을 정의하는 문서입니다.',to_date('22/03/02','RR/MM/DD'),1,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (32,'WebForge: 기능 명세서','기능 명세서는 시스템이 제공해야 하는 기능을 상세히 설명하는 문서입니다. 각 기능의 동작과 예상되는 결과를 정의하여 개발자들이 해당 기능을 구현할 수 있도록 합니다.',to_date('22/03/02','RR/MM/DD'),1,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (33,'WebForge: 화면 설계서','화면 설계서는 사용자 인터페이스의 레이아웃, 디자인, 기능 등을 설명하는 문서입니다. 각 화면의 구성 요소, 버튼, 입력 필드 등 시각적인 요소를 정의하여 개발자와 디자이너가 일관된 인터페이스를 개발할 수 있도록 돕습니다.',to_date('22/03/12','RR/MM/DD'),2,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (34,'WebForge: 데이터베이스 설계서','데이터베이스 설계서는 시스템에서 사용되는 데이터의 구조와 관계를 설명하는 문서입니다. 데이터베이스 테이블, 필드, 관계 등을 정의하여 데이터의 구조와 정합성을 유지하며 개발할 수 있도록 합니다.',to_date('22/03/22','RR/MM/DD'),2,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (35,'WebForge: 소스 코드','소스 코드는 프로그램의 구현을 위한 프로그래밍 언어로 작성된 코드입니다. 소스 코드는 프로젝트의 기능과 로직을 실제로 구현하며, 프로그래머가 이를 작성하고 유지보수합니다.',to_date('22/04/02','RR/MM/DD'),3,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (36,'WebForge: 위험 관리 계획서','위험 관리 계획서는 프로젝트의 위험을 관리하고 대응하기 위한 계획을 정의하는 문서입니다. 프로젝트에서 발생할 수 있는 위험을 식별하고, 예방 및 대응 방안을 수립하여 프로젝트의 성공을 보장합니다.',to_date('22/04/22','RR/MM/DD'),3,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (37,'WebForge: 변경 제어 문서','변경 제어 문서는 프로젝트에서 변경 사항을 관리하기 위한 문서입니다. 변경 요청의 승인 절차, 변경 사항의 기록, 영향 분석 등을 포함하여 프로젝트 변경의 투명성과 제어를 보장합니다.',to_date('22/05/02','RR/MM/DD'),4,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (38,'WebForge: 프로젝트 보고서','프로젝트 보고서는 프로젝트 진행 상황과 결과를 보고하는 문서입니다. 주요 단계, 성과, 문제점, 해결 방안 등을 포함하여 이해관계자들에게 프로젝트의 현황을 전달합니다.',to_date('22/06/02','RR/MM/DD'),4,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (39,'WebForge: 프로젝트 배포 및 운영 문서','프로젝트 배포 및 운영 문서는 시스템을 실제 운영 환경으로 배포하고 관리하기 위한 문서입니다. 배포 절차, 시스템 구성, 운영 및 모니터링 방법 등을 기술하여 안정적인 운영을 보장합니다.',to_date('22/07/12','RR/MM/DD'),5,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (40,'WebForge: 프로젝트 유지보수 문서','프로젝트 유지보수 문서는 시스템의 유지보수를 위한 문서입니다. 시스템 구성, 버그 및 이슈 추적, 변경 이력 등을 기록하여 효율적인 유지보수를 지원합니다.',to_date('22/08/22','RR/MM/DD'),5,10);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (42,'요구분석서','금융상품 추천 어플리케이션 제작 요구분석서 입니다.',to_date('23/06/12','RR/MM/DD'),1,1);
Insert into TEAM.PRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,EMPLOYEESEQ,PROJECTSEQ) values (44,'웹 서버 프로젝트 산출물','산출물 등록합니다.',to_date('23/06/12','RR/MM/DD'),2,10);
--------------------------------------------------------
--  DDL for Index SYS_C008950
--------------------------------------------------------

  CREATE UNIQUE INDEX "TEAM"."SYS_C008950" ON "TEAM"."PRODUCT" ("PRODUCTSEQ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table PRODUCT
--------------------------------------------------------

  ALTER TABLE "TEAM"."PRODUCT" ADD PRIMARY KEY ("PRODUCTSEQ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "TEAM"."PRODUCT" MODIFY ("PROJECTSEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PRODUCT" MODIFY ("EMPLOYEESEQ" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PRODUCT" MODIFY ("PRODUCTDATE" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PRODUCT" MODIFY ("CONTENT" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PRODUCT" MODIFY ("PRODUCTNAME" NOT NULL ENABLE);
  ALTER TABLE "TEAM"."PRODUCT" MODIFY ("PRODUCTSEQ" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table PRODUCT
--------------------------------------------------------

  ALTER TABLE "TEAM"."PRODUCT" ADD FOREIGN KEY ("EMPLOYEESEQ")
	  REFERENCES "TEAM"."EMPLOYEE" ("EMPLOYEESEQ") ENABLE;
