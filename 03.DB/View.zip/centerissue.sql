--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View CENTERISSUE
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."CENTERISSUE" ("NAME", "TITLE", "ISSUETYPE", "ISSUEDATE", "DEADLINE", "ISSUESEQ", "STATUS", "PROJECTSEQ", "ISSUECONTENT") AS 
  SELECT e.name, i.title, i.issuetype, to_char(i.issuedate, 'yyyy-mm-dd') AS issuedate, to_char(i.deadline,'yyyy-mm-dd') as deadline, i.issueseq, i.status, p.projectseq, i.issuecontent
FROM issue i
INNER JOIN employee e
    ON i.employeeseq = e.employeeseq
INNER JOIN project p
    ON i.projectseq = p.projectseq
;
REM INSERTING into TEAM.CENTERISSUE
SET DEFINE OFF;
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최재현','수정사항 확인','고객변심','2023-06-12','2023-06-12',44,'w',4,'이슈 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최재현','고객 변심건 확인 요청','고객변심','2023-03-02','2022-04-19',39,'w',10,'고객 변심건 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최재현','추가 수정사항입니다.','고객변심','2023-06-10','2023-06-17',15,'y',1,'클라이언트 요청입니다. 확인부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최재현','고객변심 이슈입니다.','고객변심','2023-06-09','2023-06-12',14,'y',1,'확인 부탁드립니다. ddfd');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최재현','소스 코드 오류','일정지연','2022-05-11','2022-05-13',2,'y',1,'수정한 소스 코드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('한지현','일정 지연 확인요청','일정지연','2023-04-24','2023-05-26',40,'y',10,'고객 변심건으로 인한 일정 연기 확인부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('한지현','새로운 기능 추가','승인신청','2022-03-10','2022-03-14',1,'y',1,'프로젝트 기능 추가 목록 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('권민린','리소스 수정사항 확인','승인신청','2023-07-11','2022-07-15',41,'w',10,'리소스 수정사항 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('권민린','수정사항 검토','승인신청','2022-03-04','2022-03-05',3,'y',1,'수정사항 반영한 파일 업로드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('강성제','검토 리스트 수정','승인신청','2023-08-05','2023-09-01',42,'y',10,'검토 리스트 수정 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('강성제','테스트 진행 검토','승인신청','2022-05-18','2022-05-22',4,'y',1,'테스트 진행 후 검토사항입니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('서재수','고객 요구사항 추가','승인신청','2022-03-22','2022-03-23',5,'y',2,'고객 요구사항 추가사항 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최호재','소스 코드 오류','일정지연','2022-05-15','2022-05-17',6,'y',2,'수정한 소스 코드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('서정엽','금일 회의 후 수정사항 반영','승인신청','2022-08-09','2022-08-17',8,'y',2,'회의 후 수정사항 반영한 파일 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('임현우','일정 연기 확인','일정지연','2022-06-11','2022-06-20',7,'y',2,'회의 참석으로 인한 일정연기  확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('안훈현','일정 지연 확인요청','일정지연','2022-05-24','2022-05-26',10,'y',3,'고객 변심건으로 인한 일정 연기 확인부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('윤훈재','고객 변심건 확인 요청','고객변심','2022-04-15','2022-04-19',9,'y',3,'고객 변심건 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('이제민','리소스 수정사항 확인','승인신청','2022-07-11','2022-07-15',11,'y',3,'리소스 수정사항 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('송현진','검토 리스트 수정','승인신청','2022-08-05','2022-08-11',12,'y',3,'검토 리스트 수정 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('임재지','새로운 기능 추가','승인신청','2022-03-10','2022-03-14',16,'y',4,'프로젝트 기능 추가 목록 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('류우호','소스 코드 오류','일정지연','2022-05-11','2022-05-13',17,'y',4,'수정한 소스 코드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('전성연','수정사항 검토','승인신청','2022-03-04','2022-03-05',43,'y',4,'수정사항 반영한 파일 업로드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('한민동','테스트 진행 검토','승인신청','2022-05-18','2022-05-22',18,'w',4,'테스트 진행 후 검토사항입니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('장태수','고객 요구사항 추가','승인신청','2022-03-22','2022-03-23',19,'y',5,'고객 요구사항 추가사항 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('박완제','소스 코드 오류','일정지연','2022-05-15','2022-05-17',20,'y',5,'수정한 소스 코드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('오욱섭','일정 연기 확인','일정지연','2022-06-11','2022-06-20',21,'w',5,'회의 참석으로 인한 일정연기  확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('이지완','금일 회의 후 수정사항 반영','승인신청','2022-08-09','2022-08-17',22,'y',5,'회의 후 수정사항 반영한 파일 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('임지소','고객 변심건 확인 요청','고객변심','2022-04-15','2022-04-19',23,'y',6,'고객 변심건 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('오섭린','일정 지연 확인요청','일정지연','2022-05-24','2022-05-26',24,'y',6,'고객 변심건으로 인한 일정 연기 확인부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('전연림','리소스 수정사항 확인','승인신청','2022-07-11','2022-07-15',25,'y',6,'리소스 수정사항 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('이훈소','검토 리스트 수정','승인신청','2022-08-05','2022-08-11',26,'y',6,'검토 리스트 수정 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('임재제','새로운 기능 추가','승인신청','2022-03-10','2022-03-14',27,'w',7,'프로젝트 기능 추가 목록 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('오소현','소스 코드 오류','일정지연','2022-05-11','2022-05-13',28,'y',7,'수정한 소스 코드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('박소진','수정사항 검토','승인신청','2022-03-04','2022-03-05',29,'y',7,'수정사항 반영한 파일 업로드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('전엽현','테스트 진행 검토','승인신청','2022-05-18','2022-05-22',30,'w',7,'테스트 진행 후 검토사항입니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('최채현','고객 요구사항 추가','승인신청','2022-03-22','2022-03-23',31,'y',8,'고객 요구사항 추가사항 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('류소현','소스 코드 오류','일정지연','2022-05-15','2022-05-17',32,'w',8,'수정한 소스 코드 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('안동엽','일정 연기 확인','일정지연','2022-06-11','2022-06-20',33,'y',8,'회의 참석으로 인한 일정연기  확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('김진정','금일 회의 후 수정사항 반영','승인신청','2022-08-09','2022-08-17',34,'y',8,'회의 후 수정사항 반영한 파일 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('서현정','고객 변심건 확인 요청','고객변심','2022-04-15','2022-04-19',35,'y',9,'고객 변심건 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('강성호','일정 지연 확인요청','일정지연','2022-05-24','2022-05-26',36,'w',9,'고객 변심건으로 인한 일정 연기 확인부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('강현린','리소스 수정사항 확인','승인신청','2022-07-11','2022-07-15',37,'y',9,'리소스 수정사항 확인 부탁드립니다.');
Insert into TEAM.CENTERISSUE (NAME,TITLE,ISSUETYPE,ISSUEDATE,DEADLINE,ISSUESEQ,STATUS,PROJECTSEQ,ISSUECONTENT) values ('서호린','검토 리스트 수정','승인신청','2022-08-05','2022-08-11',38,'y',9,'검토 리스트 수정 확인 부탁드립니다.');
