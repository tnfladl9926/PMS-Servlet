--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View VWNOTICE
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."VWNOTICE" ("NOTICEDATE", "TITLE", "NOTICETYPE", "NAME", "NOTICESEQ") AS 
  select to_char(noticedate,'yyyy-mm-dd') as noticedate, n.title as title, n.noticetype as noticetype, e.name, noticeseq  from notice n
inner join employee e
on n.employeeseq = e.employeeseq order by noticedate desc
;
REM INSERTING into TEAM.VWNOTICE
SET DEFINE OFF;
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2023-05-13','사내 홍보 행사 일정 안내','전체','권성린',10);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2023-04-08','긴급 서버 점검 안내','전체','권성린',9);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2023-02-04','신입사원 교육 일정 공지','전체','권성린',8);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-12-15','급여 정산 일정 안내','전체','권성린',7);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-11-30','사내 행사 안내 - 기업 송년 파티','전체','권성린',6);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-07-15','클라이언트 미팅 날짜 변경 안내','팀별','송소수',25);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-07-15','클라이언트 미팅 날짜 변경 안내','팀별','전연현',20);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-06-07','네트워크 점검 예정 안내','전체','권성린',5);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-05-27','작업 우선순위 조정 안내','팀별','전연현',19);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-05-27','작업 우선순위 조정 안내','팀별','송소수',24);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-05-15','클라이언트 미팅 날짜 변경 안내','팀별','오현소',15);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-05-11','휴가 신청 절차 변경 안내','전체','권성린',4);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-04-27','작업 우선순위 조정 안내','팀별','오현소',14);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-04-15','사내 인트라넷 서비스 개선 안내','전체','권성린',3);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-04-10','근로시간 조정 안내','전체','권성린',2);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-04-05','팀 내 커뮤니케이션 도구 변경 안내','팀별','전연현',18);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-04-05','팀 내 커뮤니케이션 도구 변경 안내','팀별','송소수',23);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-03-30','보안 강화 조치 안내','전체','권성린',1);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-03-28','변경 사항 관련 미팅 일정 안내','팀별','전연현',17);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-03-28','변경 사항 관련 미팅 일정 안내','팀별','송소수',22);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-03-10','주간 진행 상황 보고 안내','팀별','전연현',16);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-03-10','주간 진행 상황 보고 안내','팀별','송소수',21);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-03-05','팀 내 커뮤니케이션 도구 변경 안내','팀별','오현소',13);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-02-28','변경 사항 관련 미팅 일정 안내','팀별','오현소',12);
Insert into TEAM.VWNOTICE (NOTICEDATE,TITLE,NOTICETYPE,NAME,NOTICESEQ) values ('2022-01-10','주간 진행 상황 보고 안내','팀별','오현소',11);
