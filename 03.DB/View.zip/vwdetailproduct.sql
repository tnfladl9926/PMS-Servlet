--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View VWDETAILPRODUCT
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."VWDETAILPRODUCT" ("PRODUCTSEQ", "PRODUCTNAME", "PRODUCTDATE", "CONTENT", "PROJECTNAME", "FILENAME", "FILESEQ", "EMPLOYEENAME") AS 
  select 
    p.productseq,
    p.productname,
    p.productdate,
    p.content,
    (select name from project where projectseq = p.projectseq) as projectname,
    pf.filename,
    pf.fileseq,
    (select name from employee where employeeseq = p.employeeseq) as employeename
from product p
inner join productfile pf
on p.productseq = pf.productseq
;
REM INSERTING into TEAM.VWDETAILPRODUCT
SET DEFINE OFF;
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (1,'금융 프로젝트 요구사항 명세서',to_date('22/01/09','RR/MM/DD'),'금융 프로젝트 요구사항에 대한 명세서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 요구사항 명세서',1,'오현소');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (2,'금융 프로젝트 기술 명세서',to_date('22/02/10','RR/MM/DD'),'금융 프로젝트 기술 명세서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 기술 명세서',2,'오현소');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (3,'금융 프로젝트 화면 설계서',to_date('22/03/15','RR/MM/DD'),'금융 프로젝트 화면 설계서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 화면 설계서',3,'최재현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (4,'금융 프로젝트 데이터베이스 설계서',to_date('22/03/25','RR/MM/DD'),'금융 프로젝트 데이터베이스 설계서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 데이터베이스 설계서',4,'최재현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (5,'금융 프로젝트 소스코드',to_date('22/04/20','RR/MM/DD'),'금융 프로젝트 소스코드입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 소스코드',5,'한지현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (6,'금융 프로젝트 위험 관리 계획서',to_date('22/04/30','RR/MM/DD'),'금융 프로젝트 위험 관리 계획서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 위험 관리 계획서',6,'한지현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (7,'금융 프로젝트 변경 제어 문서',to_date('22/05/15','RR/MM/DD'),'금융 프로젝트 변경 제어 문서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 변경 제어 문서',7,'권민린');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (8,'금융 프로젝트 보고서',to_date('22/05/28','RR/MM/DD'),'금융 프로젝트 보고서 산출물입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 보고서',8,'권민린');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (9,'금융 프로젝트 배포 및 운영 문서',to_date('22/05/31','RR/MM/DD'),'금융 프로젝트 배포 및 운영 문서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 배포 및 운영 문서',9,'강성제');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (10,'금융 프로젝트 유지 보수 문서',to_date('22/06/01','RR/MM/DD'),'금융 프로젝트 유지 보수 문서입니다.','금융상품 추천 어플리케이션 제작','금융 프로젝트 유지 보수 문서',10,'강성제');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (11,'크롤링 프로그램 요구사항 명세서',to_date('22/03/15','RR/MM/DD'),'크롤링 프로그램 요구사항 명세서입니다.','웹 크롤링 프로그램 제작','크롤링 프로그램 요구사항 명세서',11,'전연현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (12,'크롤링 프로그램 기술 명세서',to_date('22/03/23','RR/MM/DD'),'크롤링 프로그램 기술 명세서입니다.','웹 크롤링 프로그램 제작','크롤링 프로그램 기술 명세서',12,'전연현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (13,'크롤링 프로그램 화면 설계서',to_date('22/04/05','RR/MM/DD'),'크롤링 프로그램 화면 설계서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 화면 설계서',13,'서재수');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (14,'크롤링 프로그램 데이터베이스 설계서',to_date('22/04/26','RR/MM/DD'),'크롤링 프로그램 데이터베이스 설계서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 데이터베이스 설계서',14,'서재수');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (15,'크롤링 프로그램 소스코드',to_date('22/07/18','RR/MM/DD'),'크롤링 프로그램 소스코드입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 소스코드',15,'최호재');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (16,'크롤링 프로그램 위험 관리 계획서',to_date('22/07/27','RR/MM/DD'),'크롤링 프로그램 위험 관리 계획서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 위험 관리 계획서',16,'최호재');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (17,'크롤링 프로그램 변경 제어 문서',to_date('22/08/11','RR/MM/DD'),'크롤링 프로그램 변경 제어 문서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 변경 제어 문서',17,'서정엽');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (18,'크롤링 프로그램 보고서',to_date('22/08/13','RR/MM/DD'),'크롤링 프로그램 보고서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 보고서',18,'서정엽');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (19,'크롤링 프로그램 배포 및 운영 문서',to_date('22/08/17','RR/MM/DD'),'크롤링 프로그램 배포 및 운영 문서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 배포 및 운영 문서',19,'임현우');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (20,'크롤링 프로그램 유지 보수 문서',to_date('22/09/01','RR/MM/DD'),'크롤링 프로그램 유지 보수 문서입니다.','웹 크롤링 프로그램 제작','크롤링 프로젝트 유지 보수 문서',20,'임현우');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (21,'POS프로그램 요구사항 명세서',to_date('22/03/15','RR/MM/DD'),'POS프로그램 유지 보수 문서입니다.','POS프로그램 제작','POS프로젝트 요구사항 명세서',21,'송소수');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (22,'POS프로그램 기술 명세서',to_date('22/03/23','RR/MM/DD'),'POS프로그램 기술 명세서입니다.','POS프로그램 제작','POS프로젝트 기술 명세서',22,'송소수');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (23,'POS프로그램 화면 설계서',to_date('22/04/05','RR/MM/DD'),'POS프로그램 화면 설계서입니다.','POS프로그램 제작','POS프로젝트 화면 설계서',23,'안훈현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (24,'POS프로그램 데이터베이스 설계서',to_date('22/04/26','RR/MM/DD'),'POS프로그램 데이터베이스 설계서입니다.','POS프로그램 제작','POS프로젝트 데이터베이스 설계서',24,'안훈현');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (25,'POS프로그램 소스코드',to_date('22/07/18','RR/MM/DD'),'POS프로그램 소스코드입니다.','POS프로그램 제작','POS프로젝트 소스코드',25,'윤훈재');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (26,'POS프로그램 위험 관리 계획서',to_date('22/07/27','RR/MM/DD'),'POS프로그램 위험 관리 계획서입니다.','POS프로그램 제작','POS프로젝트 위험 관리 계획서',26,'윤훈재');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (27,'POS프로그램 변경 제어 문서',to_date('22/08/11','RR/MM/DD'),'POS프로그램 변경 제어 문서입니다.','POS프로그램 제작','POS프로젝트 변경 제어 문서',27,'이제민');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (28,'POS프로그램 보고서',to_date('22/08/13','RR/MM/DD'),'POS프로그램 보고서입니다.','POS프로그램 제작','POS프로젝트 보고서',28,'이제민');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (29,'POS프로그램 배포 및 운영 문서',to_date('22/08/17','RR/MM/DD'),'POS프로그램 배포 및 운영 문서입니다.','POS프로그램 제작','POS프로젝트 배포 및 운영 문서',29,'송현진');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (30,'POS프로그램 유지 보수 문서',to_date('22/09/01','RR/MM/DD'),'POS프로그램 유지 보수 문서입니다.','POS프로그램 제작','POS프로젝트 유지 보수 문서',30,'송현진');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (31,'WebForge: 요구사항 명세서',to_date('22/03/02','RR/MM/DD'),'요구사항 명세서는 프로젝트의 목적과 범위, 사용자 및 시스템 요구사항을 정의하는 문서입니다.','WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼','결재 안건 요청서.pdf',115,'오현소');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (32,'WebForge: 기능 명세서',to_date('22/03/02','RR/MM/DD'),'기능 명세서는 시스템이 제공해야 하는 기능을 상세히 설명하는 문서입니다. 각 기능의 동작과 예상되는 결과를 정의하여 개발자들이 해당 기능을 구현할 수 있도록 합니다.','WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼','결재 안건 요청서.pdf',116,'오현소');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (40,'WebForge: 프로젝트 유지보수 문서',to_date('22/08/22','RR/MM/DD'),'프로젝트 유지보수 문서는 시스템의 유지보수를 위한 문서입니다. 시스템 구성, 버그 및 이슈 추적, 변경 이력 등을 기록하여 효율적인 유지보수를 지원합니다.','WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼','결재 안건 요청서.pdf',108,'강성제');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (42,'요구분석서',to_date('23/06/12','RR/MM/DD'),'금융상품 추천 어플리케이션 제작 요구분석서 입니다.','금융상품 추천 어플리케이션 제작','결재 안건 요청서2.pdf',112,'오현소');
Insert into TEAM.VWDETAILPRODUCT (PRODUCTSEQ,PRODUCTNAME,PRODUCTDATE,CONTENT,PROJECTNAME,FILENAME,FILESEQ,EMPLOYEENAME) values (44,'웹 서버 프로젝트 산출물',to_date('23/06/12','RR/MM/DD'),'산출물 등록합니다.','WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼','산출물.pdf',113,'최재현');
