--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View VWISSUE
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."VWISSUE" ("ISSUEDATE", "TITLE", "NAME", "DEADLINE", "ISSUESEQ", "STATUS", "ISSUECONTENT", "ISSUETYPE") AS 
  select to_char(issuedate,'yyyy-mm-dd') as issuedate, title, e.name, to_char(deadline,'yyyy-mm-dd') as deadline, issueseq,status, issuecontent, issuetype
from issue i 
inner join employee e on i.employeeSeq = e.employeeseq
inner join project p on p.projectseq = i.projectseq
;
REM INSERTING into TEAM.VWISSUE
SET DEFINE OFF;
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-06-12','수정사항 확인','최재현','2023-06-12',44,'w','이슈 확인 부탁드립니다.','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-03-02','고객 변심건 확인 요청','최재현','2022-04-19',39,'w','고객 변심건 확인 부탁드립니다.','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-06-10','추가 수정사항입니다.','최재현','2023-06-17',15,'y','클라이언트 요청입니다. 확인부탁드립니다.','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-06-09','고객변심 이슈입니다.','최재현','2023-06-12',14,'y','확인 부탁드립니다. ddfd','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-11','소스 코드 오류','최재현','2022-05-13',2,'y','수정한 소스 코드 확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-04-24','일정 지연 확인요청','한지현','2023-05-26',40,'y','고객 변심건으로 인한 일정 연기 확인부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-10','새로운 기능 추가','한지현','2022-03-14',1,'y','프로젝트 기능 추가 목록 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-07-11','리소스 수정사항 확인','권민린','2022-07-15',41,'w','리소스 수정사항 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-04','수정사항 검토','권민린','2022-03-05',3,'y','수정사항 반영한 파일 업로드 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2023-08-05','검토 리스트 수정','강성제','2023-09-01',42,'y','검토 리스트 수정 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-18','테스트 진행 검토','강성제','2022-05-22',4,'y','테스트 진행 후 검토사항입니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-22','고객 요구사항 추가','서재수','2022-03-23',5,'y','고객 요구사항 추가사항 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-15','소스 코드 오류','최호재','2022-05-17',6,'y','수정한 소스 코드 확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-08-09','금일 회의 후 수정사항 반영','서정엽','2022-08-17',8,'y','회의 후 수정사항 반영한 파일 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-06-11','일정 연기 확인','임현우','2022-06-20',7,'y','회의 참석으로 인한 일정연기  확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-24','일정 지연 확인요청','안훈현','2022-05-26',10,'y','고객 변심건으로 인한 일정 연기 확인부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-04-15','고객 변심건 확인 요청','윤훈재','2022-04-19',9,'y','고객 변심건 확인 부탁드립니다.','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-07-11','리소스 수정사항 확인','이제민','2022-07-15',11,'y','리소스 수정사항 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-08-05','검토 리스트 수정','송현진','2022-08-11',12,'y','검토 리스트 수정 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-10','새로운 기능 추가','임재지','2022-03-14',16,'y','프로젝트 기능 추가 목록 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-11','소스 코드 오류','류우호','2022-05-13',17,'y','수정한 소스 코드 확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-04','수정사항 검토','전성연','2022-03-05',43,'y','수정사항 반영한 파일 업로드 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-18','테스트 진행 검토','한민동','2022-05-22',18,'w','테스트 진행 후 검토사항입니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-22','고객 요구사항 추가','장태수','2022-03-23',19,'y','고객 요구사항 추가사항 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-15','소스 코드 오류','박완제','2022-05-17',20,'y','수정한 소스 코드 확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-06-11','일정 연기 확인','오욱섭','2022-06-20',21,'w','회의 참석으로 인한 일정연기  확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-08-09','금일 회의 후 수정사항 반영','이지완','2022-08-17',22,'y','회의 후 수정사항 반영한 파일 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-04-15','고객 변심건 확인 요청','임지소','2022-04-19',23,'y','고객 변심건 확인 부탁드립니다.','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-24','일정 지연 확인요청','오섭린','2022-05-26',24,'y','고객 변심건으로 인한 일정 연기 확인부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-07-11','리소스 수정사항 확인','전연림','2022-07-15',25,'y','리소스 수정사항 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-08-05','검토 리스트 수정','이훈소','2022-08-11',26,'y','검토 리스트 수정 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-10','새로운 기능 추가','임재제','2022-03-14',27,'w','프로젝트 기능 추가 목록 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-11','소스 코드 오류','오소현','2022-05-13',28,'y','수정한 소스 코드 확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-04','수정사항 검토','박소진','2022-03-05',29,'y','수정사항 반영한 파일 업로드 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-18','테스트 진행 검토','전엽현','2022-05-22',30,'w','테스트 진행 후 검토사항입니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-03-22','고객 요구사항 추가','최채현','2022-03-23',31,'y','고객 요구사항 추가사항 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-15','소스 코드 오류','류소현','2022-05-17',32,'w','수정한 소스 코드 확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-06-11','일정 연기 확인','안동엽','2022-06-20',33,'y','회의 참석으로 인한 일정연기  확인 부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-08-09','금일 회의 후 수정사항 반영','김진정','2022-08-17',34,'y','회의 후 수정사항 반영한 파일 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-04-15','고객 변심건 확인 요청','서현정','2022-04-19',35,'y','고객 변심건 확인 부탁드립니다.','고객변심');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-05-24','일정 지연 확인요청','강성호','2022-05-26',36,'w','고객 변심건으로 인한 일정 연기 확인부탁드립니다.','일정지연');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-07-11','리소스 수정사항 확인','강현린','2022-07-15',37,'y','리소스 수정사항 확인 부탁드립니다.','승인신청');
Insert into TEAM.VWISSUE (ISSUEDATE,TITLE,NAME,DEADLINE,ISSUESEQ,STATUS,ISSUECONTENT,ISSUETYPE) values ('2022-08-05','검토 리스트 수정','서호린','2022-08-11',38,'y','검토 리스트 수정 확인 부탁드립니다.','승인신청');
