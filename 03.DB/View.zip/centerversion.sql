--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View CENTERVERSION
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."CENTERVERSION" ("VERSIONSEQ", "VERSION", "CONTENT", "VERSIONDATE", "FILENAME", "PROJECTSEQ", "NAME") AS 
  select vs.versionseq, vs.version, vs.content, to_char(vs.versiondate,'yyyy-mm-dd') as versiondate, vs.filename, p.projectseq, p.name
from version vs
inner join project p
on vs.projectseq = p.projectseq
order by versionseq desc
;
REM INSERTING into TEAM.CENTERVERSION
SET DEFINE OFF;
Insert into TEAM.CENTERVERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ,NAME) values (24,'베타버전','금융상품 추천 어플리케이션의 베타버전은 개인 맞춤형 금융 조언을 제공하는 혁신적인 플랫폼입니다. 이 어플리케이션은 사용자의 금융 목표, 수입 및 지출 패턴, 투자 성향 등을 분석하여 최적의 금융상품을 추천해 줍니다.

베타버전에서는 사용자의 프로필 정보를 수집하고, 그에 기반하여 금융상품 추천 알고리즘을 테스트합니다. 이를 통해 사용자는 자신에게 가장 적합한 예금 상품, 대출 상품, 투자 상품 등을 발견할 수 있습니다.

또한, 베타버전에서는 금융 교육 자료와 투자 팁, 재무 관리 가이드 등의 추가 기능도 제공됩니다. 이를 통해 사용자는 금융적인 지식과 노하우를 습득하며 자신의 재무 상태를 효과적으로 관리할 수 있습니다.

베타버전은 사용자의 피드백과 경험을 수집하여 서비스를 개선하는 데 활용될 것입니다. 최종 버전에서는 더 많은 기능과 개인화된 추천 알고리즘을 제공하여 사용자의 금융적인 목표 달성을 도와줄 것입니다.




','2023-05-31','금융상품 추천 어플리케이션 1.pdf',1,'금융상품 추천 어플리케이션 제작');
Insert into TEAM.CENTERVERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ,NAME) values (22,'1.16','버전 업데이트입니다.','2023-06-11','결재 안건 요청서.pdf',1,'금융상품 추천 어플리케이션 제작');
Insert into TEAM.CENTERVERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ,NAME) values (21,'1.12','금융상품 추천 어플리케이션 제작의 다섯번째 버전','2023-06-10','버전 파일2.pdf',1,'금융상품 추천 어플리케이션 제작');
Insert into TEAM.CENTERVERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ,NAME) values (3,'1.03','금융상품 추천 어플리케이션 제작의 네번째 버전','2022-09-01',null,1,'금융상품 추천 어플리케이션 제작');
Insert into TEAM.CENTERVERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ,NAME) values (2,'1.02','금융상품 추천 어플리케이션 제작의 세번째 버전','2022-06-01',null,1,'금융상품 추천 어플리케이션 제작');
Insert into TEAM.CENTERVERSION (VERSIONSEQ,VERSION,CONTENT,VERSIONDATE,FILENAME,PROJECTSEQ,NAME) values (1,'1.01','금융상품 추천 어플리케이션 제작의 두번째 버전','2022-03-01',null,1,'금융상품 추천 어플리케이션 제작');
