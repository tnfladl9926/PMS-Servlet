--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View VWPRODUCT
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."VWPRODUCT" ("PRODUCTSEQ", "PROJECTSEQ", "PJNAME", "EMPLOYEESEQ", "PRODUCTNAME", "EMNAME", "PRODUCTDATE") AS 
  select p.productseq,pj.projectseq ,pj.name as pjname,e.employeeseq ,p.productname, e.name as emname, to_char(p.productdate ,'yyyy-mm-dd') as productdate
from
product p inner join project pj on p.projectseq = pj.projectseq
inner join employee e on e.employeeseq = p.employeeseq
order by productdate desc
;
REM INSERTING into TEAM.VWPRODUCT
SET DEFINE OFF;
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (42,1,'금융상품 추천 어플리케이션 제작',1,'요구분석서','오현소','2023-06-12');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (44,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',2,'웹 서버 프로젝트 산출물','최재현','2023-06-12');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (30,3,'POS프로그램 제작',15,'POS프로그램 유지 보수 문서','송현진','2022-09-01');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (20,2,'웹 크롤링 프로그램 제작',10,'크롤링 프로그램 유지 보수 문서','임현우','2022-09-01');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (40,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',5,'WebForge: 프로젝트 유지보수 문서','강성제','2022-08-22');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (29,3,'POS프로그램 제작',15,'POS프로그램 배포 및 운영 문서','송현진','2022-08-17');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (19,2,'웹 크롤링 프로그램 제작',10,'크롤링 프로그램 배포 및 운영 문서','임현우','2022-08-17');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (18,2,'웹 크롤링 프로그램 제작',9,'크롤링 프로그램 보고서','서정엽','2022-08-13');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (28,3,'POS프로그램 제작',14,'POS프로그램 보고서','이제민','2022-08-13');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (17,2,'웹 크롤링 프로그램 제작',9,'크롤링 프로그램 변경 제어 문서','서정엽','2022-08-11');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (27,3,'POS프로그램 제작',14,'POS프로그램 변경 제어 문서','이제민','2022-08-11');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (16,2,'웹 크롤링 프로그램 제작',8,'크롤링 프로그램 위험 관리 계획서','최호재','2022-07-27');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (26,3,'POS프로그램 제작',13,'POS프로그램 위험 관리 계획서','윤훈재','2022-07-27');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (15,2,'웹 크롤링 프로그램 제작',8,'크롤링 프로그램 소스코드','최호재','2022-07-18');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (25,3,'POS프로그램 제작',13,'POS프로그램 소스코드','윤훈재','2022-07-18');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (39,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',5,'WebForge: 프로젝트 배포 및 운영 문서','강성제','2022-07-12');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (38,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',4,'WebForge: 프로젝트 보고서','권민린','2022-06-02');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (10,1,'금융상품 추천 어플리케이션 제작',5,'금융 프로젝트 유지 보수 문서','강성제','2022-06-01');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (9,1,'금융상품 추천 어플리케이션 제작',5,'금융 프로젝트 배포 및 운영 문서','강성제','2022-05-31');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (8,1,'금융상품 추천 어플리케이션 제작',4,'금융 프로젝트 보고서','권민린','2022-05-28');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (7,1,'금융상품 추천 어플리케이션 제작',4,'금융 프로젝트 변경 제어 문서','권민린','2022-05-15');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (37,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',4,'WebForge: 변경 제어 문서','권민린','2022-05-02');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (6,1,'금융상품 추천 어플리케이션 제작',3,'금융 프로젝트 위험 관리 계획서','한지현','2022-04-30');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (24,3,'POS프로그램 제작',12,'POS프로그램 데이터베이스 설계서','안훈현','2022-04-26');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (14,2,'웹 크롤링 프로그램 제작',7,'크롤링 프로그램 데이터베이스 설계서','서재수','2022-04-26');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (36,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',3,'WebForge: 위험 관리 계획서','한지현','2022-04-22');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (5,1,'금융상품 추천 어플리케이션 제작',3,'금융 프로젝트 소스코드','한지현','2022-04-20');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (23,3,'POS프로그램 제작',12,'POS프로그램 화면 설계서','안훈현','2022-04-05');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (13,2,'웹 크롤링 프로그램 제작',7,'크롤링 프로그램 화면 설계서','서재수','2022-04-05');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (35,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',3,'WebForge: 소스 코드','한지현','2022-04-02');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (4,1,'금융상품 추천 어플리케이션 제작',2,'금융 프로젝트 데이터베이스 설계서','최재현','2022-03-25');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (12,2,'웹 크롤링 프로그램 제작',6,'크롤링 프로그램 기술 명세서','전연현','2022-03-23');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (22,3,'POS프로그램 제작',11,'POS프로그램 기술 명세서','송소수','2022-03-23');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (34,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',2,'WebForge: 데이터베이스 설계서','최재현','2022-03-22');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (21,3,'POS프로그램 제작',11,'POS프로그램 요구사항 명세서','송소수','2022-03-15');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (11,2,'웹 크롤링 프로그램 제작',6,'크롤링 프로그램 요구사항 명세서','전연현','2022-03-15');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (3,1,'금융상품 추천 어플리케이션 제작',2,'금융 프로젝트 화면 설계서','최재현','2022-03-15');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (33,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',2,'WebForge: 화면 설계서','최재현','2022-03-12');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (31,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',1,'WebForge: 요구사항 명세서','오현소','2022-03-02');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (32,10,'WebForge: 웹 서버를 구축, 관리하는 데 필요한 도구를 제공하는 플랫폼',1,'WebForge: 기능 명세서','오현소','2022-03-02');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (2,1,'금융상품 추천 어플리케이션 제작',1,'금융 프로젝트 기술 명세서','오현소','2022-02-10');
Insert into TEAM.VWPRODUCT (PRODUCTSEQ,PROJECTSEQ,PJNAME,EMPLOYEESEQ,PRODUCTNAME,EMNAME,PRODUCTDATE) values (1,1,'금융상품 추천 어플리케이션 제작',1,'금융 프로젝트 요구사항 명세서','오현소','2022-01-09');
