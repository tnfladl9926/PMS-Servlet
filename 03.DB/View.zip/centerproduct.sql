--------------------------------------------------------
--  파일이 생성됨 - 목요일-6월-15-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for View CENTERPRODUCT
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "TEAM"."CENTERPRODUCT" ("PRODUCTSEQ", "PRODUCTNAME", "CONTENT", "PRODUCTDATE", "PROJECTSEQ", "NAME", "LV") AS 
  select p.productseq, p.productname, p.content, to_char(p.productdate,'yyyy-mm-dd') as productdate, p.projectseq, e.name, e.lv
from product p
inner join employee e
on p.employeeseq = e.employeeseq
;
REM INSERTING into TEAM.CENTERPRODUCT
SET DEFINE OFF;
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (42,'요구분석서','금융상품 추천 어플리케이션 제작 요구분석서 입니다.','2023-06-12',1,'오현소',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (32,'WebForge: 기능 명세서','기능 명세서는 시스템이 제공해야 하는 기능을 상세히 설명하는 문서입니다. 각 기능의 동작과 예상되는 결과를 정의하여 개발자들이 해당 기능을 구현할 수 있도록 합니다.','2022-03-02',10,'오현소',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (31,'WebForge: 요구사항 명세서','요구사항 명세서는 프로젝트의 목적과 범위, 사용자 및 시스템 요구사항을 정의하는 문서입니다.','2022-03-02',10,'오현소',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (2,'금융 프로젝트 기술 명세서','금융 프로젝트 기술 명세서입니다.','2022-02-10',1,'오현소',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (1,'금융 프로젝트 요구사항 명세서','금융 프로젝트 요구사항에 대한 명세서입니다.','2022-01-09',1,'오현소',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (44,'웹 서버 프로젝트 산출물','산출물 등록합니다.','2023-06-12',10,'최재현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (34,'WebForge: 데이터베이스 설계서','데이터베이스 설계서는 시스템에서 사용되는 데이터의 구조와 관계를 설명하는 문서입니다. 데이터베이스 테이블, 필드, 관계 등을 정의하여 데이터의 구조와 정합성을 유지하며 개발할 수 있도록 합니다.','2022-03-22',10,'최재현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (33,'WebForge: 화면 설계서','화면 설계서는 사용자 인터페이스의 레이아웃, 디자인, 기능 등을 설명하는 문서입니다. 각 화면의 구성 요소, 버튼, 입력 필드 등 시각적인 요소를 정의하여 개발자와 디자이너가 일관된 인터페이스를 개발할 수 있도록 돕습니다.','2022-03-12',10,'최재현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (4,'금융 프로젝트 데이터베이스 설계서','금융 프로젝트 데이터베이스 설계서입니다.','2022-03-25',1,'최재현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (3,'금융 프로젝트 화면 설계서','금융 프로젝트 화면 설계서입니다.','2022-03-15',1,'최재현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (36,'WebForge: 위험 관리 계획서','위험 관리 계획서는 프로젝트의 위험을 관리하고 대응하기 위한 계획을 정의하는 문서입니다. 프로젝트에서 발생할 수 있는 위험을 식별하고, 예방 및 대응 방안을 수립하여 프로젝트의 성공을 보장합니다.','2022-04-22',10,'한지현',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (35,'WebForge: 소스 코드','소스 코드는 프로그램의 구현을 위한 프로그래밍 언어로 작성된 코드입니다. 소스 코드는 프로젝트의 기능과 로직을 실제로 구현하며, 프로그래머가 이를 작성하고 유지보수합니다.','2022-04-02',10,'한지현',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (6,'금융 프로젝트 위험 관리 계획서','금융 프로젝트 위험 관리 계획서입니다.','2022-04-30',1,'한지현',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (5,'금융 프로젝트 소스코드','금융 프로젝트 소스코드입니다.','2022-04-20',1,'한지현',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (38,'WebForge: 프로젝트 보고서','프로젝트 보고서는 프로젝트 진행 상황과 결과를 보고하는 문서입니다. 주요 단계, 성과, 문제점, 해결 방안 등을 포함하여 이해관계자들에게 프로젝트의 현황을 전달합니다.','2022-06-02',10,'권민린',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (37,'WebForge: 변경 제어 문서','변경 제어 문서는 프로젝트에서 변경 사항을 관리하기 위한 문서입니다. 변경 요청의 승인 절차, 변경 사항의 기록, 영향 분석 등을 포함하여 프로젝트 변경의 투명성과 제어를 보장합니다.','2022-05-02',10,'권민린',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (8,'금융 프로젝트 보고서','금융 프로젝트 보고서 산출물입니다.','2022-05-28',1,'권민린',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (7,'금융 프로젝트 변경 제어 문서','금융 프로젝트 변경 제어 문서입니다.','2022-05-15',1,'권민린',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (40,'WebForge: 프로젝트 유지보수 문서','프로젝트 유지보수 문서는 시스템의 유지보수를 위한 문서입니다. 시스템 구성, 버그 및 이슈 추적, 변경 이력 등을 기록하여 효율적인 유지보수를 지원합니다.','2022-08-22',10,'강성제',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (39,'WebForge: 프로젝트 배포 및 운영 문서','프로젝트 배포 및 운영 문서는 시스템을 실제 운영 환경으로 배포하고 관리하기 위한 문서입니다. 배포 절차, 시스템 구성, 운영 및 모니터링 방법 등을 기술하여 안정적인 운영을 보장합니다.','2022-07-12',10,'강성제',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (10,'금융 프로젝트 유지 보수 문서','금융 프로젝트 유지 보수 문서입니다.','2022-06-01',1,'강성제',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (9,'금융 프로젝트 배포 및 운영 문서','금융 프로젝트 배포 및 운영 문서입니다.','2022-05-31',1,'강성제',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (12,'크롤링 프로그램 기술 명세서','크롤링 프로그램 기술 명세서입니다.','2022-03-23',2,'전연현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (11,'크롤링 프로그램 요구사항 명세서','크롤링 프로그램 요구사항 명세서입니다.','2022-03-15',2,'전연현',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (14,'크롤링 프로그램 데이터베이스 설계서','크롤링 프로그램 데이터베이스 설계서입니다.','2022-04-26',2,'서재수',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (13,'크롤링 프로그램 화면 설계서','크롤링 프로그램 화면 설계서입니다.','2022-04-05',2,'서재수',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (16,'크롤링 프로그램 위험 관리 계획서','크롤링 프로그램 위험 관리 계획서입니다.','2022-07-27',2,'최호재',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (15,'크롤링 프로그램 소스코드','크롤링 프로그램 소스코드입니다.','2022-07-18',2,'최호재',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (18,'크롤링 프로그램 보고서','크롤링 프로그램 보고서입니다.','2022-08-13',2,'서정엽',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (17,'크롤링 프로그램 변경 제어 문서','크롤링 프로그램 변경 제어 문서입니다.','2022-08-11',2,'서정엽',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (20,'크롤링 프로그램 유지 보수 문서','크롤링 프로그램 유지 보수 문서입니다.','2022-09-01',2,'임현우',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (19,'크롤링 프로그램 배포 및 운영 문서','크롤링 프로그램 배포 및 운영 문서입니다.','2022-08-17',2,'임현우',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (22,'POS프로그램 기술 명세서','POS프로그램 기술 명세서입니다.','2022-03-23',3,'송소수',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (21,'POS프로그램 요구사항 명세서','POS프로그램 유지 보수 문서입니다.','2022-03-15',3,'송소수',2);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (24,'POS프로그램 데이터베이스 설계서','POS프로그램 데이터베이스 설계서입니다.','2022-04-26',3,'안훈현',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (23,'POS프로그램 화면 설계서','POS프로그램 화면 설계서입니다.','2022-04-05',3,'안훈현',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (26,'POS프로그램 위험 관리 계획서','POS프로그램 위험 관리 계획서입니다.','2022-07-27',3,'윤훈재',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (25,'POS프로그램 소스코드','POS프로그램 소스코드입니다.','2022-07-18',3,'윤훈재',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (28,'POS프로그램 보고서','POS프로그램 보고서입니다.','2022-08-13',3,'이제민',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (27,'POS프로그램 변경 제어 문서','POS프로그램 변경 제어 문서입니다.','2022-08-11',3,'이제민',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (30,'POS프로그램 유지 보수 문서','POS프로그램 유지 보수 문서입니다.','2022-09-01',3,'송현진',1);
Insert into TEAM.CENTERPRODUCT (PRODUCTSEQ,PRODUCTNAME,CONTENT,PRODUCTDATE,PROJECTSEQ,NAME,LV) values (29,'POS프로그램 배포 및 운영 문서','POS프로그램 배포 및 운영 문서입니다.','2022-08-17',3,'송현진',1);
